package com.duanqu.qupaicustomuidemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.duanqu.qupaicustomuidemo.Auth.AuthTest;
import com.duanqu.qupaicustomuidemo.session.RenderRequest;
import com.duanqu.qupaicustomuidemo.session.VideoSessionClientFactoryImpl;
import com.duanqu.qupaicustomuidemo.trim.ImportActivity;
import com.duanqu.qupaicustomuidemo.utils.Constant;

public class MainActivity extends Activity implements View.OnClickListener{
    Button btn_auth;
    Button btn_record;
    Button btn_trim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_auth = (Button)findViewById(R.id.btn_auth);
        btn_record = (Button) findViewById(R.id.btn_record);
        btn_trim = (Button) findViewById(R.id.btn_trim);
        btn_auth.setOnClickListener(this);
        btn_record.setOnClickListener(this);
        btn_trim.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_auth:
                //鉴权，请先务必调用鉴权，并且鉴权成功.如果鉴权失败不要调用拍摄.
                AuthTest.getInstance().initAuth(v.getContext(), Constant.APP_KEY,Constant.APP_SECRET,Constant.SPACE);
                break;
            case R.id.btn_record:
                if(Constant.accessToken == null){
                    Toast.makeText(v.getContext(),v.getResources().getString(R.string.auth_tips),Toast.LENGTH_LONG).show();
                    return;
                }
                new RecordActivity.Request(new VideoSessionClientFactoryImpl(), null)
                        .startForResult(MainActivity.this, RenderRequest.RENDER_MODE_EXPORT_VIDEO);
            break;
            case R.id.btn_trim:
                if(Constant.accessToken == null){
                    Toast.makeText(v.getContext(),v.getResources().getString(R.string.auth_tips),Toast.LENGTH_LONG).show();
                    return;
                }
                Intent intentTrim =new Intent();
                intentTrim.setClass(v.getContext(),ImportActivity.class);
                startActivity(intentTrim);
                break;
        }
    }
}
