package com.duanqu.qupaicustomuidemo;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.duanqu.qupai.android.camera.CameraClient;
import com.duanqu.qupai.android.widget.AspectRatioLayout;
import com.duanqu.qupai.engine.session.PageRequest;
import com.duanqu.qupai.engine.session.SessionClientFactory;
import com.duanqu.qupai.engine.session.SessionPageRequest;
import com.duanqu.qupai.media.Recorder9;
import com.duanqu.qupai.project.Clip;
import com.duanqu.qupai.project.ProjectConnection;
import com.duanqu.qupai.recorder.ClipManager;
import com.duanqu.qupai.recorder.RecorderTask;
import com.duanqu.qupai.render.BeautyRenderer;
import com.duanqu.qupai.utils.DisplayUtil;
import com.duanqu.qupaicustomuidemo.trim.ImportActivity;
import com.duanqu.qupaicustomuidemo.uicomponent.BeautySkinSlider;
import com.duanqu.qupaicustomuidemo.uicomponent.BeautySkinSwitch;
import com.duanqu.qupaicustomuidemo.uicomponent.BeautySkinTips_TextView;
import com.duanqu.qupaicustomuidemo.uicomponent.CameraSwitch;
import com.duanqu.qupaicustomuidemo.uicomponent.CountDownSwitch;
import com.duanqu.qupaicustomuidemo.uicomponent.CountDownTips;
import com.duanqu.qupaicustomuidemo.uicomponent.FocusAreaMediator;
import com.duanqu.qupaicustomuidemo.uicomponent.PreviewSurface;
import com.duanqu.qupaicustomuidemo.uicomponent.RecordSession;
import com.duanqu.qupaicustomuidemo.uicomponent.SimpleWorkspace;
import com.duanqu.qupaicustomuidemo.uicomponent.TimelineIndicator;
import com.duanqu.qupaicustomuidemo.uicomponent.TimelineSlider;
import com.duanqu.qupaicustomuidemo.uicomponent.TimelineTimeLayout;
import com.duanqu.qupaicustomuidemo.uicomponent.ZoomIndicator;
import com.duanqu.qupaicustomuidemo.editor.EditorActivity;
import com.duanqu.qupaicustomuidemo.session.RenderRequest;
import com.duanqu.qupaicustomuidemo.session.VideoSessionClientFactoryImpl;
import com.duanqu.qupaicustomuidemo.utils.Constant;

import java.io.Serializable;

public class RecordActivity extends Activity {

    private View mRootView;
    private CameraClient mCameraClient;
    private BeautyRenderer mBeautyRenderer;
    private ClipManager mClipManager;
    private TimelineSlider mTimelineSlider;
    private RecordSession mRecordSession;
    private ViewMonitor mViewMonitor = new ViewMonitor();

    private ImageView mTvGallery;
    private ImageView mIvDeleteClip;
    private ImageView mIvRecord;
    private ImageView mIvNextStep;
    private TimelineIndicator mTimeLineIndicator;
    private CountDownSwitch countDownSwitch;

    public static final String KEY_NEXT = "KEY_NEXT";

    Request _Request;

    public static final class Request extends SessionPageRequest {

        public Request(SessionPageRequest original) {
            super(original);
        }

        public Request(SessionClientFactory factory, Serializable data) {
            super(factory, data);
        }

        private transient Intent _NextIntent;

        public Request setNextIntent(Intent intent) {
            _NextIntent = intent;
            return this;
        }

        private transient Uri _ProjectUri;

        public Request setProjectUri(Uri uri) {
            _ProjectUri = uri;
            return this;
        }

        private int _DefaultMV = -1;

        int getDefaultMV() {
            return _DefaultMV;
        }

        public Request setDefaultMV(int id) {
            _DefaultMV = id;
            return this;
        }

        private int _DefaultDIYOverlayGroup = -1;

        int getDefaultDIYOverlayGroup() {
            return _DefaultDIYOverlayGroup;
        }

        public Request setDefaultDIYOverlayGroup(int id) {
            _DefaultDIYOverlayGroup = id;
            return this;
        }

        @Override
        protected void marshall(Intent intent) {
            super.marshall(intent);

            intent.setData(_ProjectUri);
            intent.putExtra(KEY_NEXT, _NextIntent);
        }

        @Override
        protected void unmarshall(Intent intent) {
            super.unmarshall(intent);

            _ProjectUri = intent.getData();
            _NextIntent = intent.getParcelableExtra(KEY_NEXT);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        _Request = PageRequest.from(this);

        mRootView = ((ViewGroup) findViewById(android.R.id.content)).getChildAt(0);

        int surface_width = _Request.getVideoSessionClient(this).getProjectOptions().videoWidth;
        int surface_height = _Request.getVideoSessionClient(this).getProjectOptions().videoHeight;

        /*
         * CameraClient代表一个摄像头资源对象,所有
         */
        mCameraClient = new CameraClient();

        //设置摄像头方向（前置摄像头 or 后置摄像头）
        mCameraClient.setCameraFacing(Camera.CameraInfo.CAMERA_FACING_BACK);

        //设置手机屏幕旋转角度
        mCameraClient.setDisplayRotation(DisplayUtil.getDisplayRotation(this));

        //设置摄像头开启错误监听
        mCameraClient.setOnErrorListener(mCameraClientErrorListener);

        ProjectConnection project_conn = new ProjectConnection(new SimpleWorkspace(this, _Request.getVideoSessionClient(this).getJSONSupport()));
        project_conn.createNewProject();

        //创建一个Clip管理器，Clip以及时常的管理都是在这里完成
        mClipManager = new ClipManager(project_conn);

        //最大允许拍摄时常（这里是指所有Clip总的拍摄时长，而不是单个clip的时长）,单位：毫秒
        mClipManager.setMaxDuration(15000);

        //最小有效拍摄时常（也是指所有Clip的总时长，而不是单个Clip的时长）
        mClipManager.setMinDuration(3000);

        //设置单个Clip变化的监听（一般是在拍摄时，单个Clip会持续更新，像拍摄进度的一些更新操作都可以在这里执行）
        mClipManager.setOnClipChangeListener(mClipChangeListener);

        //Clip list变化的监听，比如拍摄完成增加Clip或者删除Clip都会触发这里的回调
        mClipManager.setOnClipListChangeListener(mClipListChangeListener);

        //创建一个美颜的Renderer
        mBeautyRenderer = new BeautyRenderer(getAssets());

        //设置美颜Renderer
        mCameraClient.setRendererCallback(mBeautyRenderer);

        /**
         * 设置摄像头数据输出模式，美颜功能必须使用CameraClient.MODE_GLSURFACE，
         * 这里使用软件编码，需要拿到视频裸数据,
         * 所以需要也设置为CameraClient.MODE_BUFFER
         */
        mCameraClient.setMode(CameraClient.MODE_GLSURFACE | CameraClient.MODE_BUFFER);
        mCameraClient.setContentSize(_Request.getVideoSessionClient(this).getProjectOptions().videoWidth, _Request.getVideoSessionClient(this).getProjectOptions().videoHeight);

        View view_backspace = findViewById(R.id.ImageView_backspace);
        view_backspace.setOnClickListener(mBackSpaceListener);

        //美颜
        BeautySkinTips_TextView beautySkinTips_textView = new BeautySkinTips_TextView((TextView) findViewById(R.id.TextView_beautyTips));

        BeautySkinSwitch beauty_skin_switch = new BeautySkinSwitch(findViewById(R.id.ImageView_beautyBtn), mBeautyRenderer);
        beauty_skin_switch.addOnBeautyEnabledListener(beautySkinTips_textView);

        BeautySkinSlider beautySkinIndicator = new BeautySkinSlider(findViewById(R.id.LinearLayout_skinProcess), beauty_skin_switch);
        beauty_skin_switch.addOnBeautyEnabledListener(beautySkinIndicator);
        beauty_skin_switch.enableBeautySkin(false);

        View switch_camera = findViewById(R.id.ImageButton_cameraSwitch);
        if (Camera.getNumberOfCameras() > 1) {
            switch_camera.setVisibility(View.VISIBLE);
            new CameraSwitch(switch_camera, mCameraClient);
        } else {
            switch_camera.setVisibility(View.GONE);
        }

        AspectRatioLayout camera_frame = (AspectRatioLayout) findViewById(R.id.preview_frame);
        camera_frame.setOriginalSize(surface_width, surface_height);

        //缩放
        ZoomIndicator zoom_indicator = new ZoomIndicator((TextView) findViewById(R.id.TextView_zoomIndicator));
        //对焦
        FocusAreaMediator focus_area = new FocusAreaMediator(findViewById(R.id.View_focus_area));

        PreviewSurface surface_listener = new PreviewSurface(
                (SurfaceView) findViewById(R.id.SurfaceView_previewSurface), surface_width, surface_height, mCameraClient);
        surface_listener.setZoomIndicator(zoom_indicator);
        surface_listener.setFocusAreaMediator(focus_area);

        mTimelineSlider = new TimelineSlider(mRootView, mClipManager);

        //下一步按钮
        mIvNextStep = (ImageView) findViewById(R.id.imageView_nextBtn);
        mIvNextStep.setOnClickListener(mViewMonitor);
        mIvNextStep.setEnabled(false);

        //录制按钮
        mIvRecord = (ImageView) findViewById(R.id.imageView_capture);
        mIvRecord.setOnTouchListener(mViewMonitor);

        //创建RecorderSession， 录制的开始/停止都在这里控制
        mRecordSession = new RecordSession(mClipManager, mCameraClient);

        //设置录制callback
        mRecordSession.setFeedbackListener(mFeedbackListener);

        //回删按钮
        mIvDeleteClip = (ImageView) findViewById(R.id.ImageView_clipCanceller);
        mIvDeleteClip.setOnClickListener(mViewMonitor);
        mIvDeleteClip.setVisibility(View.GONE);
        mTimeLineIndicator = new TimelineIndicator((TimelineTimeLayout) findViewById(R.id.timeline_time_layout), mClipManager);

        mTvGallery = (ImageView)findViewById(R.id.btn_gallery);
        mTvGallery.setOnClickListener(mViewMonitor);

        //倒计时拍摄
        CountDownTips countdown_tips = new CountDownTips((TextView) findViewById(R.id.TextView_countdownTips),
                findViewById(R.id.LinearLayout_countdownTips), this, mRecordSession);
        countDownSwitch = new CountDownSwitch(findViewById(R.id.ImageButton_countdownSwitch), countdown_tips);
    }

    @Override
    protected void onResume() {
        super.onResume();

        mRecordSession.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mRecordSession.onPause();
        countDownSwitch.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRecordSession.onDestroy();
    }

    private View.OnClickListener mBackSpaceListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            /* if countdown record is on going, stop it */
            onBackPressed();
        }
    };

    private CameraClient.OnErrorListener mCameraClientErrorListener = new CameraClient.OnErrorListener() {
        @Override
        public void onError(CameraClient client, int id) {
            Toast toast = Toast.makeText(getActivity(), R.string.qupai_message_camera_acquisition_failure, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
            TextView text = (TextView) toast.getView().findViewById(android.R.id.message);
            text.setGravity(Gravity.CENTER);

            toast.show();
        }
    };

    private ClipManager.Listener mClipListChangeListener = new ClipManager.Listener() {
        @Override
        public void onClipListChange(ClipManager manager, int event) {
            mIvDeleteClip.setVisibility(manager.getClipCount()>0?View.VISIBLE:View.GONE);
            mTvGallery.setVisibility(manager.getClipCount()>0?View.GONE:View.VISIBLE);
            mTimelineSlider.onClipListChange(mClipManager, event);
            mIvDeleteClip.setActivated(manager.isLastClipSelected());
            mTimeLineIndicator.onClipListChange(manager, event);
            if (manager.getDuration() >= manager.getMinDuration()) {
                mIvNextStep.setEnabled(true);
            } else {
                mIvNextStep.setEnabled(false);
            }
        }
    };

    private ClipManager.OnClipChangeListener mClipChangeListener = new ClipManager.OnClipChangeListener() {
        @Override
        public void onClipChange(ClipManager manager, Clip vb) {
            mTimelineSlider.onClipChange(manager, vb);
            mTimeLineIndicator.onClipChange(manager, vb);
        }
    };

    private Activity getActivity() {
        return this;
    }

    Recorder9.OnFeedbackListener mFeedbackListener = new Recorder9.OnFeedbackListener() {
        @Override
        public void onLimitReached(Recorder9 rec, long timestamp) {
            mRecordSession.requestStop();
        }

        @Override
        public void onProgress(Recorder9 rec, long timestamp) {

        }

        @Override
        public void OnCompletion(Recorder9 rec) {
            if (mClipManager.getDuration() >= mClipManager.getMaxDuration()) {
                mClipManager.saveProject();
                Toast.makeText(RecordActivity.this, "已保存", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void OnRecorderTaskCompletion(Recorder9 rec, RecorderTask task) {
            String file = task.getVideoFile();
            Log.d("RecorderTask", "Video file is : " + file);
        }

        @Override
        public void onError(Recorder9 rec, Throwable tr) {

        }
    };


    class ViewMonitor implements View.OnClickListener, View.OnTouchListener {


        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mRecordSession.requestStart();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    mRecordSession.requestStop();
                    break;
            }
            return true;
        }


        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.ImageView_clipCanceller:
                    if (mClipManager.isLastClipSelected()) {
                        mClipManager.removeLastClip(null);
                    } else {
                        boolean selected = mClipManager.setLastClipSelected(true);
                        mIvDeleteClip.setActivated(selected);
                    }
                    break;
                case R.id.imageView_nextBtn:
                    mClipManager.saveProject();

                    new EditorActivity.Request(new VideoSessionClientFactoryImpl(), null)
                            .setProjectUri(mClipManager.getProject().getUri())
                            .startForResult(RecordActivity.this, RenderRequest.RENDER_MODE_EXPORT_VIDEO);
                    break;
                case R.id.btn_gallery:
                    if(Constant.accessToken == null){
                        Toast.makeText(v.getContext(),v.getResources().getString(R.string.auth_tips),Toast.LENGTH_LONG).show();
                        return;
                    }
                    Intent intentTrim =new Intent();
                    intentTrim.setClass(v.getContext(),ImportActivity.class);
                    startActivity(intentTrim);
                    break;
            }
        }
    }
}
