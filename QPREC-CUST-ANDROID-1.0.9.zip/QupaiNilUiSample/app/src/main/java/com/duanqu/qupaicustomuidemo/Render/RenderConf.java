package com.duanqu.qupaicustomuidemo.Render;

import android.net.Uri;
import android.util.Log;

import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.orch.SoundProjectFactory;
import com.duanqu.qupai.orch.project.SoundProject;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.stage.SceneFactory;
import com.duanqu.qupai.stage.scene.Scene;

import java.io.File;

/**
 * Created by qupai on 16-4-25.
 * 渲染参数配置器
 */
public abstract class RenderConf {
    private static final String TAG = "";

    private Project mProject;
    private double mDurationLimit = 8.0;
    private int mVideoFrameRate;

    private SceneFactory mSceneFactory = null;
    private SoundProjectFactory mSoundProjectFactory = null;
    private JSONSupport mJSON;


    public RenderConf(Project project, SceneFactory.Client sceneClient, SoundProjectFactory.Client soundClient,
                      JSONSupport json) {
        this.mProject = project;
        this.mSceneFactory = new SceneFactory(sceneClient);
        this.mSoundProjectFactory = new SoundProjectFactory(soundClient);
        this.mJSON = json;
    }



    public abstract String getRenderOutputFilePath();


    public abstract String getExportThumbnailPath();

    public abstract String getExportThumbnailWithoutAnimationPath();



    public abstract String getPreviewThumbnailPath();


    public File getProjectDir() { return mProject.getProjectDir(); }


    public String getBaseURL() {
        return Uri.fromFile(mProject.getProjectDir()).toString();
    }

    public int getVideoWidth() {
        return mProject.getCanvasWidth();
    }

    public int getVideoHeight() {
        return mProject.getCanvasHeight();
    }

    public SceneFactory.SceneOptions newSceneOptions() {
        SceneFactory.SceneOptions options = new SceneFactory.SceneOptions();
        options.durationLimit = mDurationLimit;
        options.frameRate = mVideoFrameRate;
        options.width = getVideoWidth();
        options.height = getVideoHeight();
        return options;
    }

    public SoundProjectFactory.SoundOptions newSoundOptions() {
        SoundProjectFactory.SoundOptions options = new SoundProjectFactory.SoundOptions();
        options.durationLimit = mDurationLimit;
        return options;
    }

    public String getSceneJSON(SceneFactory.SceneOptions options) {
        Scene scene = mSceneFactory.getScene(mProject, options);

        try {
            return mJSON.writeValue(scene);
        } catch (Exception e) {
            Log.e(TAG, "error serializing scene", e);
            return null;
        }
    }

    public String getSoundJSON(SoundProjectFactory.SoundOptions options) {
        if ( (mProject.getType() !=  Project.TYPE_VIDEO)) {
            return null;
        }
        SoundProject sound = mSoundProjectFactory.getSound(mProject, options);
        try {
            return mJSON.writeValue(sound);
        } catch (Exception e) {
            Log.e(TAG, "error serializing sound", e);
            return null;
        }
    }

    public double getDurationLimit() {
        return mDurationLimit;
    }

    public void setDurationLimit(double durationLimit) {
        mDurationLimit = durationLimit;
    }

    public int getVideoFrameRate() {
        return mVideoFrameRate;
    }

    public void setVideoFrameRate(int videoFrameRate) {
        mVideoFrameRate = videoFrameRate;
    }
}
