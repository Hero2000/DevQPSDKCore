package com.duanqu.qupaicustomuidemo.Render;

import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.orch.SoundProjectFactory;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.stage.SceneFactory;

/**
 * Created by qupai on 16-5-9.
 */
public class RenderConfImpl extends RenderConf {
    public RenderConfImpl(Project project, SceneFactory.Client sceneClient, SoundProjectFactory.Client soundClient, JSONSupport json) {
        super(project, sceneClient, soundClient, json);
    }

    public  String getRenderOutputFilePath() {
        return getProjectDir().getAbsolutePath() + "/export.mp4";
    }

    public String getExportThumbnailPath() {
        return getProjectDir().getAbsolutePath() + "/export-%d.png";
    }

    public String getExportThumbnailWithoutAnimationPath() {
        return getProjectDir().getAbsolutePath() + "/without-export-%d.png";
    }

    public String getPreviewThumbnailPath() {
        return getProjectDir().getAbsolutePath() + "/preview-%d.png";
    }
}
