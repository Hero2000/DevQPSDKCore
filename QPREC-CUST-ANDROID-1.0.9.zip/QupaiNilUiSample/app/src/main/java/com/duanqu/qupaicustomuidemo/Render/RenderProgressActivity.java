package com.duanqu.qupaicustomuidemo.Render;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.engine.session.MovieExportOptions;
import com.duanqu.qupai.engine.session.PageRequest;
import com.duanqu.qupai.engine.session.ProjectOptions;
import com.duanqu.qupai.engine.session.SessionClientFactory;
import com.duanqu.qupai.engine.session.SessionPageRequest;
import com.duanqu.qupai.engine.session.ThumbnailExportOptions;
import com.duanqu.qupai.engine.session.VideoSessionClient;
import com.duanqu.qupai.engine.session.VideoSessionCreateInfo;
import com.duanqu.qupai.frontend.android.RenderTask;
import com.duanqu.qupai.orch.SoundProjectFactory;
import com.duanqu.qupai.orch.android.SoundProjectFactoryClient;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.ProjectUtil;
import com.duanqu.qupai.render.RenderTaskManager;
import com.duanqu.qupai.stage.SceneFactory;
import com.duanqu.qupai.stage.android.BitmapLoader;
import com.duanqu.qupai.stage.android.SceneFactoryClient;
import com.duanqu.qupai.stage.android.StageHost;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupaicustomuidemo.Scene.ImageFadeScene;
import com.duanqu.qupaicustomuidemo.editor.EditorActivity;
import com.duanqu.qupaicustomuidemo.session.RenderRequest;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

public class RenderProgressActivity extends Activity implements View.OnClickListener, RenderTaskManager.OnRenderTaskListener {

    public static class Request extends RenderRequest {

        public Request(SessionPageRequest original) {
            super(original);
        }

        public Request(SessionClientFactory factory, Serializable data) {
            super(factory, data);
        }

        @Override
        public SessionPageRequest setFactory(SessionClientFactory factory) {
            return super.setFactory(factory);
        }

        private transient Uri _ProjectUri;

        public Request setProjectUri(Uri uri) {
            _ProjectUri = uri;
            return this;
        }

        @Override
        protected void marshall(Intent intent) {
            super.marshall(intent);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            intent.setData(_ProjectUri);
        }

        @Override
        protected void unmarshall(Intent intent) {
            super.unmarshall(intent);

            intent.setData(_ProjectUri);
        }

    }

    private RenderTaskManager _RenderTaskManager;
    private StageHost _StageHost;

    private ProgressBar _RenderProgress;
    private TextView _RenderText;
    private Button mBtnGoEditor;
    private Project mProject;
    private RenderConf mRenderConf;

    Request request;
    VideoSessionClient videoSessionClient;
    VideoSessionCreateInfo videoSessionCreateInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_qupai_render_progress);

        _RenderProgress = (ProgressBar) findViewById(R.id.renderProgress);
        _RenderText = (TextView) findViewById(R.id.renderText);
        mBtnGoEditor = (Button) findViewById(R.id.btn_go_editor);
        mBtnGoEditor.setOnClickListener(this);

        initVideoSesionCreateInfo();
    }

    private void initVideoSesionCreateInfo() {
        request = PageRequest.from(this);
        videoSessionClient =  request.getVideoSessionClient(this);
        videoSessionCreateInfo= videoSessionClient.getCreateInfo();

        //声音相关
        SoundProjectFactoryClient soundProjectClient = new SoundProjectFactoryClient(videoSessionClient.getAssetRepository());
        //视频相关
        SceneFactoryClient sceneClient = new SceneFactoryClientImpl(this, videoSessionClient.getAssetRepository(),
                request.getVideoSessionClient(this).getJSONSupport());

        //intent传递过来的project,这里是关键，录制完成之后save为一个json文件,这里读取json文件，并且设置project的值
        File projectFile = new File(request.getProjectUri().getPath());
        mProject = ProjectUtil.readProject(projectFile, videoSessionClient.getJSONSupport());
        if (mProject != null) {
            mProject.setProjectDir(projectFile.getParentFile(), projectFile);
        }

        if (mProject.getCanvasHeight() == 0 || mProject.getCanvasWidth() == 0) {
            mProject.setCanvasSize(videoSessionClient.getProjectOptions().videoWidth, videoSessionClient.getProjectOptions().videoHeight);
        }

        mRenderConf = new RenderConfImpl(mProject, sceneClient, soundProjectClient, request.getVideoSessionClient(this).getJSONSupport());
        //最大时长
        mRenderConf.setDurationLimit(videoSessionClient.getProjectOptions().durationMax);
        //帧率
        mRenderConf.setVideoFrameRate(videoSessionClient.getProjectOptions().videoFrameRate);
        //渲染合成管理
        _RenderTaskManager = new RenderTaskManager();
        _RenderTaskManager.setOnRenderTaskListener(this);
        _StageHost = new StageHost.Builder()
                .addBitmapResolver(new BitmapLoader(this))
                .get();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (request.getRenderMode() == RenderRequest.RENDER_MODE_EXPORT_VIDEO) {
            //初始化完成之后组装需要合成的数据
            enableExportThumbnailTask(0, 20);
            enableExportTask(20, 80);
        } else if (request.getRenderMode() == RenderRequest.RENDER_MODE_EXPORT_THUMBNAIL_COMPOSE) {
            //初始化完成之后组装需要合成的数据
            enableExportThumComposeTask(1, 100, request.getPhotoList());
        }
        _RenderTaskManager.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        _RenderTaskManager.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        _RenderTaskManager.stop();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_go_editor:
                Intent intent = new Intent(this, EditorActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("project_file", mProject.getProjectFile().getAbsolutePath());
                intent.putExtras(bundle);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void onRenderTaskError(int errorCode) {
        if (errorCode == 10004) {
            Toast.makeText(this, "请先调用鉴权", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    public void onRenderTaskProgress(int progress) {
        _RenderText.setText(progress + "%");
        _RenderProgress.setProgress(progress);
    }

    @Override
    public void onRenderTaskCompletion(long elapsed_time) {
        finish();
        mProject.getDurationNano();
        mRenderConf.getRenderOutputFilePath();
        mRenderConf.getExportThumbnailPath();

        int thumbnail_count = request.getVideoSessionClient(this).getCreateInfo().getThumbnailExportOptions().count;
        String[] thumb_list = null;
        if (mRenderConf.getExportThumbnailPath() != null) {
            thumb_list = new String[thumbnail_count];
            for (int i = 0; i < thumb_list.length; i++) {
                thumb_list[i] = String.format(mRenderConf.getExportThumbnailPath(), i + 1);
            }
        }

//        try {
//            Files.move(new File(mRenderConf.getRenderOutputFilePath()), new File("/sdcard/qupai_video/output.mp4"));
//            Files.move(new File(thumb_list[0]), new File("/sdcard/qupai_video/outputimg.png"));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        finish();
    }

    //组装一个视频ExportTask
    private void enableExportTask(int progress, int total) {
        String export_path = mRenderConf.getRenderOutputFilePath();
        SceneFactory.SceneOptions scene_opt = mRenderConf.newSceneOptions();
        scene_opt.flags = Project.GENERATE_MODE_FULL_ADD_WATERMARK;
        scene_opt.watermarkPath = videoSessionCreateInfo.getWaterMarkPath();
        scene_opt.watermarkPostion = videoSessionCreateInfo.getWaterMarkPosition();

        SoundProjectFactory.SoundOptions sound_opt = mRenderConf.newSoundOptions();

        String video_content = mRenderConf.getSceneJSON(scene_opt);
        String audio_content = mRenderConf.getSoundJSON(sound_opt);

        RenderTask task = new RenderTask(_StageHost);
        task.setVideoPixelFormat(RenderTask.PIXEL_FORMAT_NV12);
        MovieExportOptions options = videoSessionCreateInfo.getMovieExportOptions();
        if (null != options) {
            task.configureVideo(options.getVideoEncoderOptions());
            task.configureMuxer(options.getMuxerOptions());
            task.setFileFormat(options.getFileFormat());
        }

        task.setContent(video_content, audio_content, mRenderConf.getBaseURL());
        task.setOutputURL(export_path);

        _RenderTaskManager.addTask(task, progress, total);
    }

    private void enableExportThumComposeTask(int progress, int total, ArrayList list) {
        String export_path = mRenderConf.getRenderOutputFilePath();
        ImageFadeScene scene = new ImageFadeScene();
        RenderTask task = new RenderTask(_StageHost);
        task.setVideoPixelFormat(RenderTask.PIXEL_FORMAT_NV12);
        MovieExportOptions options = videoSessionCreateInfo.getMovieExportOptions();
        if (null != options) {
            task.configureVideo(options.getVideoEncoderOptions());
            task.configureMuxer(options.getMuxerOptions());
            task.setFileFormat(options.getFileFormat());
        }

        task.setContent(scene.load(480, 480, list), null, mRenderConf.getBaseURL());
        task.setOutputURL(export_path);

        _RenderTaskManager.addTask(task, progress, total);
    }

    //组装一个视频ThumbnailTask
    private void enableExportThumbnailTask(int progress, int total) {
        ThumbnailExportOptions options = videoSessionCreateInfo.getThumbnailExportOptions();

        SceneFactory.SceneOptions scene_opt = mRenderConf.newSceneOptions();
        scene_opt.flags = Project.GENERATE_MODE_FULL_ADD_WATERMARK;
        scene_opt.frameCount = options.count;
        scene_opt.width = mRenderConf.getVideoWidth();
        scene_opt.height = mRenderConf.getVideoHeight();
        scene_opt.watermarkPath = videoSessionCreateInfo.getWaterMarkPath();
        scene_opt.watermarkPostion = videoSessionCreateInfo.getWaterMarkPosition();

        String video_content = mRenderConf.getSceneJSON(scene_opt);

        String export_thumbnail_path = mRenderConf.getExportThumbnailPath();
        RenderTask task = new RenderTask(_StageHost);
        task.setContent(video_content, null, mRenderConf.getBaseURL());
        task.setOutputURL(export_thumbnail_path);

        _RenderTaskManager.addTask(task, progress, total);
    }

    @Override
    public void onBackPressed() {
        _RenderTaskManager.stop();
        super.onBackPressed();
    }
}
