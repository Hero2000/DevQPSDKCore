package com.duanqu.qupaicustomuidemo.Render;

import android.content.Context;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.stage.android.SceneFactoryClient;


/**
 * XXX remove this once dependency on DynamicImage is eliminated
 */
public final class SceneFactoryClientImpl extends SceneFactoryClient {

    private static final String TAG = "SceneFactory";

    public SceneFactoryClientImpl(Context context, AssetRepository repo, JSONSupport json) {
        super(context, repo, json);
    }

}
