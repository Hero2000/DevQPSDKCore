package com.duanqu.qupaicustomuidemo.Scene;

import android.net.Uri;

import com.duanqu.qupai.jackson.JSONSupportImpl;
import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.stage.ImageFadeSceneBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

public class ImageFadeScene implements SceneLoader {

    JSONSupport _JSON = new JSONSupportImpl();

    @Override
    public String getTitle() {
        return "ImageFade";
    }

    @Override
    public String load(int w, int h, ArrayList list) {
        ImageFadeSceneBuilder builder = new ImageFadeSceneBuilder(_JSON);
        builder.setSize(w, h);
        builder.setDuration((list.size() * 3) * 30, 30, 1);
        for (int i = 0; i < list.size(); i++) {
            if (i == 0) {
                builder.addImage(list.get(i).toString(),
                        w, h,
                        i * 3, (i * 3) + 4,
                        new float[]{i, (i * 3) + 1, (i * 3) + 2, (i * 3) + 3, (i * 3) + 4,},
                        new float[]{1, 1, 1, 1, 1},
                        null
                );
            } else {
                builder.addImage(list.get(i).toString(),
                        w, h,
                        i * 3, (i * 3) + 4,
                        new float[]{(i * 3), (i * 3) + 1, (i * 3) + 2, (i * 3) + 3, (i * 3) + 4,},
                        new float[]{0, 1, 1, 1, 1},
                        getRotate()
                );

            }
        }
        try {
            return builder.get();
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }

    private float[] getRotate() {
        switch (random.nextInt(4)) {
            case 0:
                return rotate;
            case 1:
                return scale;
            case 2:
                return translatex;
            case 3:
                return translatey;
            case 4:
                return translatexy;
        }
        return scale;
    }


    float half_pi = (float) Math.PI / 2;
    //旋转
    private float[] rotate = new float[]{
            0, 0, 0, 1,
            0, 0, 0, 1,
            0, 0, 0, 1,
            0, 0, half_pi, 1,
            0, 0, 0, 1,
    };

    //缩放
    private float[] scale = new float[]{
            0, 0, 0, 1,
            0, 0, 0, 1,
            0, 0, 0, 2,
            0, 0, 0, 2,
            0, 0, 0, 1,
    };
    Random random = new Random();
    //偏移
    private float[] translatex = new float[]{
            0, 0, 0, 1,
            0, 0, 0, 1,
            0, random.nextInt(200), 0, 1,
            0, 0, 0, 1,
            0, 0, 0, 1,
    };

    //偏移
    private float[] translatey = new float[]{
            0, 0, 0, 1,
            0, 0, 0, 1,
            random.nextInt(200), 0, 0, 1,
            0, 0, 0, 1,
            0, 0, 0, 1,
    };

    //偏移
    private float[] translatexy = new float[]{
            0, 0, 0, 1,
            0, 0, 0, 1,
            random.nextInt(200), random.nextInt(200), 0, 1,
            0, 0, 0, 1,
            0, 0, 0, 1,
    };

}