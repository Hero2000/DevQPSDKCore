package com.duanqu.qupai.stage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.stage.scene.ActorGroup;
import com.duanqu.qupai.stage.scene.AnimatedGeometryProvider;
import com.duanqu.qupai.stage.scene.AnimationPass;
import com.duanqu.qupai.stage.scene.GeometryLayouts;
import com.duanqu.qupai.stage.scene.MaterialBlendMode;
import com.duanqu.qupai.stage.scene.Scene;

import javax.annotation.Nullable;

/**
 */
public class ImageFadeSceneBuilder {

    private final JSONSupport _JSON;

    public ImageFadeSceneBuilder(JSONSupport json) {
        _JSON = json;
        _Scene.root = _Root;
    }

    public String get() throws Exception {
        return _JSON.writeValue(_Scene);
    }

    private final Scene _Scene = new Scene();
    private final ActorGroup _Root = new ActorGroup();

    public void setSize(int width, int height) {
        _Scene.setSize(width, height);
    }

    public void setDuration(long duration, int time_scale, int time_step) {
        _Scene.duration = duration;
        _Scene.timeScale = time_scale;
        _Scene.timeStep = time_step;
    }

    public void addImage(String url, int width, int height, float start, float end,
                         float[] times, float[] alphas, @Nullable float[] trs) {

        ActorGroup g = new ActorGroup();
        g.inPoint = start;
        g.outPoint = end;

        AnimationPass pass = new AnimationPass();
        pass.configure(true, true, MaterialBlendMode.UNASSOCIATED_ALPHA, true);
        pass.addTexture("sTexture0", url);
        pass.update();
        g.addPass(pass);

        AnimatedGeometryProvider geom = new AnimatedGeometryProvider();
        geom.setLayout(times.length, 4, GeometryLayouts.ANI_TEX1_POINT_2D, true);

        FloatBuffer time_data = ByteBuffer.wrap(geom.timeData).order(ByteOrder.nativeOrder()).asFloatBuffer();
        FloatBuffer array_data = ByteBuffer.wrap(geom.arrayData).order(ByteOrder.nativeOrder()).asFloatBuffer();

        float cx = (float) width / 2;
        float cy = (float) height / 2;

        for (int i = 0; i < times.length; i ++) {
            float tx = (trs == null ? 0 : trs[i * 4]);
            float ty = (trs == null ? 0 : trs[i * 4 + 1]);
            float r = trs == null ? 0 : trs[i * 4 + 2];
            float s = trs == null ? 1 : trs[i * 4 + 3];
            array_data.put(new float[]{
                    cx + tx, cy + ty, - cx, - cy, r, s, 0, 0, alphas[i],
                    cx + tx, cy + ty, - cx, + cy, r, s, 0, 1, alphas[i],
                    cx + tx, cy + ty, + cx, - cy, r, s, 1, 0, alphas[i],
                    cx + tx, cy + ty, + cx, + cy, r, s, 1, 1, alphas[i],
            });
            time_data.put(times[i]);
        }

        pass.geometry = geom;

        _Root.addChild(g);
    }
}
