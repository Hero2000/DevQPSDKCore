package com.duanqu.qupaicustomuidemo.Scene;

import java.util.ArrayList;

/**
 * Created by administrator on 2016/7/12.
 */
public interface SceneLoader {
    /**
     * 场景文件的标题
     * @return
     */
    String getTitle();

    /**
     * 得到场景文件
     * @return
     */
    String load(int w,int h,ArrayList list);
}
