package com.duanqu.qupaicustomuidemo;

import android.app.Application;

import com.duanqu.qupai.engine.session.MovieExportOptions;
import com.duanqu.qupai.engine.session.ProjectOptions;
import com.duanqu.qupai.engine.session.ThumbnailExportOptions;
import com.duanqu.qupai.engine.session.VideoSessionCreateInfo;
import com.duanqu.qupai.jni.ApplicationGlue;
import com.duanqu.qupaicustomuidemo.engine.session.VideoSessionClientImpl;
import com.duanqu.qupaicustomuidemo.utils.Constant;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import java.io.File;

public class TestApplication extends Application {

    public VideoSessionClientImpl videoSessionClient;

    @Override
    public void onCreate() {
        super.onCreate();

        for (String str : new String[]{"gnustl_shared", "qupai-media-thirdparty", "qupai-media-jni"}) {
            System.loadLibrary(str);
        }

        ApplicationGlue.initialize(this);

        initVideoClientInfo();
        initImageLoader();
    }

    private void initVideoClientInfo() {
        videoSessionClient = new VideoSessionClientImpl(this);
        ProjectOptions options = new ProjectOptions.Builder()
                //输出视频帧率
                .setVideoFrameRate(24)
                //关键帧间隔
                .setIFrameInterval(2)
                //时长区间.单位：秒
                .setDurationRange(3, 15)
                .setVideoSize(480, 480)
                .get();

        MovieExportOptions movieExportOptions =new MovieExportOptions.Builder()
                .setVideoBitrate(800 * 1024)
                .setVideoPreset("faster")
                .setVideoRateCRF(6)
                .setOutputVideoLevel(30)
                .setOutputVideoTune("zerolatency")
                .setOutputVideoKeyInt(150)
                .configureMuxer("movflags", "+faststart")
                .setOutputVideoKeyInt(150)
                .build();

        ThumbnailExportOptions thumbnailExportOptions =new ThumbnailExportOptions.Builder()
                .setCount(1)
                .get();

        VideoSessionCreateInfo videoSessionCreateInfo =new VideoSessionCreateInfo.Builder()
                .setMovieExportOptions(movieExportOptions)
                .setThumbnailExportOptions(thumbnailExportOptions)
                .setWaterMarkPath(Constant.WATER_MARK_PATH)
                .setWaterMarkPosition(1)
                .build();

        videoSessionClient.setProjectOptions(options);
        videoSessionClient.setCreateInfo(videoSessionCreateInfo);
        videoSessionClient.getAssetRepository().addMusic(0, "Athena", "assets://Qupai/music/Athena");
    }

    private void initImageLoader() {
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
                getApplicationContext())
                .threadPriority(Thread.NORM_PRIORITY - 2)
                .denyCacheImageMultipleSizesInMemory()
                .threadPoolSize(3)
                .memoryCacheSize(10 * 1024 * 1024)
                .memoryCache(new LruMemoryCache(10 * 1024 * 1024))
                .diskCache(new UnlimitedDiskCache(new File(getExternalCacheDir(), "image"),
                        new File(getExternalCacheDir(), "image"),
                        new Md5FileNameGenerator()))
                .diskCacheFileNameGenerator(new Md5FileNameGenerator())
                .tasksProcessingOrder(QueueProcessingType.FIFO).build();
        ImageLoader.getInstance().init(config);
    }

}
