package com.duanqu.qupaicustomuidemo.editor;

import android.view.View;
import android.view.ViewGroup;
import com.duanqu.qupai.asset.AssetInfo;

public class AssetItemViewMediator extends EffectChooserItemViewMediator {

    public AssetItemViewMediator(ViewGroup list_view, int layout_id) {
        super(list_view, layout_id);
    }

    private AssetInfo _Data;

    private OnItemDownloadCompletion onCompletion;

    public interface OnItemDownloadCompletion {

        void onDownloadCompletion(int categoryId);

    }

    public void setOnCompletionListener(OnItemDownloadCompletion l){
        this.onCompletion = l;
    }

    public void onDownloadCompleted(){
        if(onCompletion != null){
            onCompletion.onDownloadCompletion(_Data.getGroupID());
        }
    }

    public void setData(AssetInfo asset) {

        _Data = asset;

        // TODO use a wrapper class to handle download states
        VideoEditBean bean = (VideoEditBean) asset;

        setTitle(asset.getTitle());

        setShowFontIndicator(asset.isNeedSpecialFont());

        setDownloadMask(bean.isDownloadMasked());
        setFontLocked(bean.isLocked);
        setDownloadable(bean.isDownloadable());

        displayLockIndicator(bean.shareIcon);
        //Log.d("ITEM", bean.getIconURIString());
        setImageURI(asset.getIconURIString());

    }

    public AssetInfo getValue(){
    	return _Data;
    }

    public void setTitleVisible(boolean value) {
        _Text.setVisibility(value ? View.VISIBLE : View.INVISIBLE);
    }

    public void onBind(AssetInfo info, boolean active) {
        setData(info);
        if(info.getType() == AssetInfo.TYPE_DIYOVERLAY
                || info.getType() == AssetInfo.TYPE_FONT){
            return ;
        }
        itemView.setActivated(active);
    }
}
