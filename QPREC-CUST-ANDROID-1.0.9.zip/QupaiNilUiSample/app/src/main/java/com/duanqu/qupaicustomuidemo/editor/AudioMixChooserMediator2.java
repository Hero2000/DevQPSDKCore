package com.duanqu.qupaicustomuidemo.editor;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.duanqu.qupai.asset.AssetInfo;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.asset.AssetRepository.Kind;
import com.duanqu.qupai.asset.AssetRepositoryClient;
import com.duanqu.qupai.media.android.ProjectPlayerControl;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupaicustomuidemo.Render.RenderConf;


public class AudioMixChooserMediator2 extends EditParticipant
        implements AssetListAdapter.OnItemClickListener {

    private final RecyclerView _ListView;
    private final AssetListAdapter _Adapter;

    private final View _WeightControlView;
    private EditorSession _mEditorSession;
    private final Project _mProject;
    private ProjectPlayerControl _mPlayerController;
    private RenderConf _mRenderConf;
    private AudioMixWeightControl _AudioMixWeightControl;

    public AudioMixChooserMediator2(RecyclerView list_view, View weight_control, AudioMixWeightControl audioMixWeightControl, EditorSession editorSession, AssetRepository repo
            , Project project, RenderConf renderConf, ProjectPlayerControl playerController) {

        _ListView = list_view;
        _ListView.setItemAnimator(null);

        LinearLayoutManager _LayoutManager = new LinearLayoutManager(_ListView.getContext(), LinearLayoutManager.HORIZONTAL, false);
        _ListView.setLayoutManager(_LayoutManager);

        _WeightControlView = weight_control;
        _mEditorSession = editorSession;
        _mProject = project;
        _mPlayerController = playerController;
        _mRenderConf = renderConf;
        _AudioMixWeightControl = audioMixWeightControl;

        EffectDownloadButtonMediator download_item = null;


        download_item = new EffectDownloadButtonMediator(_ListView);
        download_item.setCategory(Kind.SOUND);
        download_item.setTitle(R.string.qupai_btn_text_download_music);

        _Adapter = new AssetListAdapter(download_item,true);
        _Adapter.setData(repo.find(Kind.SOUND));
        _Adapter.setOnItemClickListener(this);
        _Adapter.setNullTitle(R.string.qupai_sound_mixer_effect_none);
        _Adapter.set_NullImage(R.drawable.ic_qupai_null_music);

        _ListView.setAdapter(_Adapter);

        AssetInfo ve = _mEditorSession.getActiveAudioAsset(repo);

        _Adapter.setActiveDataItem(ve);
    }

    @Override
    public boolean onItemClick(AssetListAdapter adapter, int adapter_position) {
        AssetInfo asset = _Adapter.getItem(adapter_position);
//        _mProject.setAudioMixVolume(0.5f);//带音乐的原始音频大小
        _mProject.setAudioMix(asset == null ? null : asset.getAssetID());
        _AudioMixWeightControl.changeSeekBar();
        updatePlayer();
        return true;
    }

    @Override
    public void setActive(boolean value) {
        super.setActive(value);
        _WeightControlView.setVisibility(value ? View.VISIBLE : View.GONE);
    }

    private void updatePlayer() {
        //生成视频参数json
        String videoContent = _mEditorSession.getVideoContent();

        //生成音频参数json
        String soundContent = _mEditorSession.getSoundContent();

        //获取project保存目录
        String baseUrl = _mRenderConf.getBaseURL();
        Log.d("EditorSession", "videoContent = " + videoContent);
        Log.d("EditorSession", "soundContent = " + soundContent);
        Log.d("EditorSession", "baseUrl = " + baseUrl);
        _mPlayerController.setContent(videoContent, soundContent, baseUrl);
        _mPlayerController.startAt(0);
    }

}
