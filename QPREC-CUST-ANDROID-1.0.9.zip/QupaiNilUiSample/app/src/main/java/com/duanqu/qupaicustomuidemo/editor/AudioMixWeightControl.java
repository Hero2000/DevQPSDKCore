package com.duanqu.qupaicustomuidemo.editor;

import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.duanqu.qupai.media.android.ProjectPlayerControl;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupaicustomuidemo.R;

public class AudioMixWeightControl
        implements OnSeekBarChangeListener {

    private final SeekBar _SeekBar;
    private final ProjectPlayerControl _Player;
    private Project _Project;

    private final View _MusicTrackText;

    public AudioMixWeightControl(View view, Project project, ProjectPlayerControl player) {
        _Player = player;
        _Project = project;

        _SeekBar = (SeekBar) view.findViewById(R.id.sb_audio_mix_weight);
        _SeekBar.setOnSeekBarChangeListener(this);
        _SeekBar.setClickable(true);
        _SeekBar.setEnabled(true);

        _MusicTrackText = view.findViewById(R.id.txt_track_music);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        float weight = (float) progress / seekBar.getMax();

        _Player.getImpl().setWeight(1 - weight);

        if (!fromUser) {
            return;
        }
        Log.d("Progress","weight" + weight);

        setPrimaryAudioWeight(1 - weight);

        weight = _Project == null ? 0 : _Project.getResolvedPrimaryAudioVolume();
        _SeekBar.setProgress((int) ((1 - weight) * _SeekBar.getMax()));
    }

    public void setPrimaryAudioWeight(float weight) {
        if (_Project.getAudioMix() != null) {
            _Project.setAudioMixVolume(1 - weight);
        } else {
            _Project.setPrimaryAudioVolume(weight);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    /**
     * TODO 建议在将project包装，在project改变的时候调用统一接口.
     */
    public void changeSeekBar(){
        float weight = _Project.getResolvedPrimaryAudioVolume();
        _SeekBar.setProgress((int) ((1 - weight) * _SeekBar.getMax()));
        _MusicTrackText.setVisibility( View.VISIBLE);
    }
}
