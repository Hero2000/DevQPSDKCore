package com.duanqu.qupaicustomuidemo.editor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.duanqu.qupai.android.widget.AspectRatioLayout;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.engine.session.PageRequest;
import com.duanqu.qupai.engine.session.SessionClientFactory;
import com.duanqu.qupai.engine.session.SessionPageRequest;
import com.duanqu.qupai.engine.session.VideoSessionClient;
import com.duanqu.qupai.media.android.ProjectPlayerControl;
import com.duanqu.qupai.orch.android.SoundProjectFactoryClient;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.ProjectConnection;
import com.duanqu.qupai.project.ProjectUtil;
import com.duanqu.qupai.project.UIEditorPage;
import com.duanqu.qupai.project.UIMode;
import com.duanqu.qupai.stage.SceneFactory;
import com.duanqu.qupai.stage.android.BitmapLoader;
import com.duanqu.qupai.stage.android.SceneFactoryClient;
import com.duanqu.qupai.stage.android.Stage;
import com.duanqu.qupai.stage.android.StageHost;
import com.duanqu.qupai.stage.android.Thumbnailer;
import com.duanqu.qupai.widget.control.TabGroup;
import com.duanqu.qupai.widget.control.TabbedViewStackBinding;
import com.duanqu.qupai.widget.control.ViewStack;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupaicustomuidemo.Render.RenderConf;
import com.duanqu.qupaicustomuidemo.Render.RenderConfImpl;
import com.duanqu.qupaicustomuidemo.Render.RenderProgressActivity;
import com.duanqu.qupaicustomuidemo.Render.SceneFactoryClientImpl;
import com.duanqu.qupaicustomuidemo.uicomponent.SimpleWorkspace;
import com.duanqu.qupaicustomuidemo.session.RenderRequest;

import java.io.File;
import java.io.Serializable;
import java.util.concurrent.TimeUnit;

public class EditorActivity extends Activity implements View.OnClickListener {

    public static final class Request extends SessionPageRequest {

        public Request(SessionPageRequest original) {
            super(original);
        }

        public Request(SessionClientFactory factory, Serializable data) {
            super(factory, data);
        }

        @Override
        public SessionPageRequest setFactory(SessionClientFactory factory) {
            return super.setFactory(factory);
        }

        private transient Uri _ProjectUri;

        public Request setProjectUri(Uri uri) {
            _ProjectUri = uri;
            return this;
        }

        @Override
        protected void marshall(Intent intent) {
            super.marshall(intent);

            intent.setData(_ProjectUri);
        }

        @Override
        protected void unmarshall(Intent intent) {
            super.unmarshall(intent);

            _ProjectUri = intent.getData();
        }
    }
    private long duration;
    private SurfaceView mDisplaySurface;
    private ProjectPlayerControl mPlayerController;
    private Project mProject;
    private RenderConf mRenderConf;
    private Stage _Stage;
    private EditorSession mEditorSession;
    private ImageView mBtnNext;
    private ImageView mBtnBack;
    private RecyclerView _ListView;
    private ProjectConnection mProjectConnection;
    private Thumbnailer _Thumbnailer;
    private TabGroup tab_group;

    private Request _Request;
    VideoSessionClient _SessionClient;

    AssetRepository dataProvider;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        _Request = PageRequest.from(this);


        //创建一个资源仓库，提供滤镜和音乐资源
        _SessionClient = _Request.getVideoSessionClient(this);
        dataProvider = _SessionClient.getAssetRepository();

        //创建一个ProjectConnection 用于保存project到本地
        mProjectConnection = new ProjectConnection(new SimpleWorkspace(this, _SessionClient.getJSONSupport()));

        //视频参数生成器
        SceneFactoryClient sceneFactoryClient = new SceneFactoryClientImpl(this, dataProvider, _SessionClient.getJSONSupport());

        //音频参数生成器
        SoundProjectFactoryClient soundFactoryClient = new SoundProjectFactoryClient(dataProvider);

        StageHost stageHost = new StageHost.Builder()
                .addBitmapResolver(new BitmapLoader(this))
//              .addBitmapResolver(new BitmapGenerator(sceneFactoryClient))
                .get();

        //创建预览播放器
        mPlayerController = new ProjectPlayerControl(stageHost);
        setContentView(R.layout.activity_editor);

        //intent传递过来的project,这里是关键，录制完成之后save为一个json文件,这里读取json文件，并且设置project的值
        String projectFilePath = _Request._ProjectUri.getPath();
        File projectFile = new File(projectFilePath);

        //根据project.json来读取属性值，生成project对象
        mProject = ProjectUtil.readProject(projectFile, _SessionClient.getJSONSupport());
        if (mProject != null) {
            mProject.setProjectDir(projectFile.getParentFile(), projectFile);
        }

        if (mProject.getCanvasHeight() == 0 || mProject.getCanvasWidth() == 0) {
            mProject.setCanvasSize(_SessionClient.getProjectOptions().videoWidth, _SessionClient.getProjectOptions().videoHeight);
        }

        mProjectConnection.setProject(mProject);

        //创建一个渲染配置器
        mRenderConf = new RenderConfImpl(mProject, sceneFactoryClient, soundFactoryClient, _SessionClient.getJSONSupport());

        //视频帧率
        mRenderConf.setVideoFrameRate(_SessionClient.getProjectOptions().videoFrameRate);

        //最大播放时常
        mRenderConf.setDurationLimit(_SessionClient.getProjectOptions().durationMax);

        mEditorSession = new EditorSession(mRenderConf, mProject);

        //缩略图的显示
        _ListView = (RecyclerView) findViewById(R.id.view_root);
        _ListView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        _Stage = new Stage(stageHost);
        _Stage.realize();

        _Thumbnailer = new Thumbnailer(_Stage, 256, 256, Looper.myLooper());

        mBtnNext = (ImageView) findViewById(R.id.btn_next);
        mBtnBack = (ImageView) findViewById(R.id.btn_back);
        mDisplaySurface = (SurfaceView) findViewById(R.id.surface_view);

        //预览播放器显示模式
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mDisplaySurface.getLayoutParams();
        VideoScaleHelper helper = new VideoScaleHelper();
        helper.setVideoWidthAndHeight(mProject.getCanvasWidth(), mProject.getCanvasHeight())
                .setScreenWidthAndHeight(screenWidth, screenWidth)
                .generateDisplayLayoutParams(lp);

        mDisplaySurface.getHolder().setFixedSize(lp.width, lp.height);
        mDisplaySurface.getHolder().addCallback(mPlayerController.getImpl().getSurface());
        //设置预览播放器
        updatePlayer();

        mBtnNext.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);
        AspectRatioLayout video_frame = (AspectRatioLayout) findViewById(R.id.video);
        video_frame.setOriginalSize(480, 480);

        ViewStack view_stack = new ViewStack(View.INVISIBLE);
        view_stack.addView(findViewById(R.id.effect_list_filter));
        view_stack.addView(findViewById(R.id.effect_list_audio_mix));

        tab_group = new TabGroup();
        tab_group.addView(findViewById(R.id.tab_effect_filter));
        tab_group.addView(findViewById(R.id.tab_effect_audio_mix));

        RecyclerView filter_list_view = (RecyclerView) findViewById(R.id.effect_list_filter);
        RecyclerView effect_list_audio_mix = (RecyclerView) findViewById(R.id.effect_list_audio_mix);

        //滤镜选择
        FilterChooserMediator2 filterChooserMediator = new FilterChooserMediator2(filter_list_view, mProject, dataProvider, mEditorSession, mRenderConf, mPlayerController);
        mEditorSession.setPart(UIEditorPage.FILTER_EFFECT, filterChooserMediator);

        //音乐选择
        View audio_mix_weight_control = findViewById(R.id.audio_mix_weight_control);
        AudioMixWeightControl audioMixWeightControl = new AudioMixWeightControl(audio_mix_weight_control, mProject, mPlayerController);
        AudioMixChooserMediator2 audio_page = new AudioMixChooserMediator2(effect_list_audio_mix, audio_mix_weight_control, audioMixWeightControl, mEditorSession
                , dataProvider, mProject, mRenderConf, mPlayerController);
        mEditorSession.setPart(UIEditorPage.AUDIO_MIX, audio_page);

        EffectChooserModeBinding _ViewStackBinding = new EffectChooserModeBinding();
        _ViewStackBinding.setViewStack(view_stack);
        tab_group.setOnCheckedChangeListener(_ViewStackBinding);
        tab_group.setCheckedIndex(0);
    }

    @Override
    protected void onStart() {
        super.onStart();
        setThumbnailerContent();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mPlayerController.startAt(0);
        mPlayerController.onStart();
        mPlayerController.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mPlayerController.onPause();
        mPlayerController.onStop();
        mPlayerController.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPlayerController.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_next:
                mProjectConnection.saveProject(UIMode.EDITOR);
                RenderRequest request = new RenderProgressActivity.Request(_Request)
                        .setProject(mProject.getUri())
                        .setRenderMode(RenderRequest.RENDER_MODE_EXPORT_VIDEO);
                request.startForResult(this, RenderRequest.RENDER_MODE_EXPORT_VIDEO);
                break;
        }
    }

    /**
     * 缩略图动态生成
     * TODO 目前这些都是以demo的形式给出.建议自己实现自己的框架或者架构
     */
    private void setThumbnailerContent() {
        duration = TimeUnit.NANOSECONDS.toMillis(mProject.getDurationNano());

        SceneFactory.SceneOptions options = new SceneFactory.SceneOptions();

        options.flags = Project.GENERATE_MODE_RECORD_PREVIEW;
        options.width = 120;
        options.height = 120;

        String video_content = mEditorSession.getVideoContent();

        _Stage.setContent(video_content, mProject.getProjectDir().toString());

        _ListView.setAdapter(new Adapter());

    }

    /**
     * 预览播放
     * TODO 目前这些都是以demo的形式给出.建议自己实现自己的框架或者架构
     */
    private void updatePlayer() {
        //生成视频参数json
        String videoContent = mEditorSession.getVideoContent();

        //生成音频参数json
        String soundContent = mEditorSession.getSoundContent();

        //获取project保存目录
        String baseUrl = mRenderConf.getBaseURL();
        Log.d("EditorSession", "videoContent = " + videoContent);
        Log.d("EditorSession", "soundContent = " + soundContent);
        Log.d("EditorSession", "baseUrl = " + baseUrl);
        mPlayerController.setContent(videoContent, soundContent, baseUrl);
    }

    private class EffectChooserModeBinding extends TabbedViewStackBinding {

        @Override
        public void onCheckedChanged(TabGroup group, int checkedIndex) {
            mEditorSession.setActiveEditorPage(UIEditorPage.get(checkedIndex));
            super.onCheckedChanged(group, checkedIndex);
        }

        public int getActiveIndex() {
            return getViewStack().getActiveIndex();
        }
    }

    private class Adapter extends RecyclerView.Adapter<ThumbnailerItem> {

        @Override
        public ThumbnailerItem onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            View item_view = inflater.inflate(R.layout.item_thumbnailer, parent, false);
            return new ThumbnailerItem(item_view);
        }

        @Override
        public void onBindViewHolder(ThumbnailerItem holder, int position) {
            holder.setData(position);
        }

        @Override
        public int getItemCount() {
            return (int) duration / 1000;
        }
    }

    private class ThumbnailerItem extends RecyclerView.ViewHolder implements Thumbnailer.OnBitmapReadyCallback {

        private final ImageView _Image;
        private final TextView _Time;

        public ThumbnailerItem(View view) {
            super(view);
            _Image = (ImageView) view.findViewById(R.id.image);
            _Time = (TextView) view.findViewById(R.id.txt_time);
        }

        public void setData(int time) {
            if (_RequestTime == time) {
                return;
            }
            _Time.setText(Integer.toString(time));
            _RequestTime = time;
            _Image.setImageBitmap(null);

            if (_RequestID >= 0) {
                _Thumbnailer.cancelRequest(_RequestID);
            }
            _RequestID = _Thumbnailer.requestImage(time, this);
        }

        private float _RequestTime = -1;
        private int _RequestID;

        @Override
        public void onBitmapReady(Thumbnailer thumbnailer, Bitmap bitmap, float time) {
            if (_RequestTime != time) {
                return;
            }
            _Image.setImageBitmap(bitmap);
            _RequestID = -1;
        }
    }
}
