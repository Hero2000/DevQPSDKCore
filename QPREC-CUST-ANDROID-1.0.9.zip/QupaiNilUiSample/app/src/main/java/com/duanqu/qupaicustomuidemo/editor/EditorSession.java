package com.duanqu.qupaicustomuidemo.editor;

import com.duanqu.qupai.asset.AssetID;
import com.duanqu.qupai.asset.AssetInfo;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.orch.SoundProjectFactory;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.UIConfiguration;
import com.duanqu.qupai.project.UIEditorPage;
import com.duanqu.qupai.stage.SceneFactory;
import com.duanqu.qupaicustomuidemo.Render.RenderConf;

/**
 * Created by qupai on 16-5-4.
 */
public class EditorSession {
    private Project mProject;
    private RenderConf mRenderConf;

    public EditorSession(RenderConf renderConf, Project project) {
        this.mRenderConf = renderConf;
        this.mProject = project;
    }

    public String getVideoContent() {
        SceneFactory.SceneOptions scene_opt = mRenderConf.newSceneOptions();
        scene_opt.flags = Project.GENERATE_MODE_FULL;
        return mRenderConf.getSceneJSON(scene_opt);
    }

    public String getSoundContent() {
        SoundProjectFactory.SoundOptions sound_opt = mRenderConf.newSoundOptions();
        return mRenderConf.getSoundJSON(sound_opt);
    }

    /**
     * 得到选中的音频
     * @param repo
     * @return
     */
    AssetInfo getActiveAudioAsset(AssetRepository repo) {
        if (mProject == null) {
            return null;
        }

        AssetID asset_id = mProject.getResolvedAudioMix();
        if (asset_id == null) {
            return null;
        }

        return repo.resolveAsset(asset_id);
    }


    public void setActiveEditorPage(UIEditorPage page) {
        UIEditorPage old_page = mProject.getUIConfig().getActiveEditorPage();
        EditParticipant old_part = _ParticipantList[old_page.index()];
        if (old_part != null) {
            old_part.setActive(false);
        }

        EditParticipant part = _ParticipantList[page.index()];
        if (part != null) {
            part.setActive(true);
        }

        if (mProject == null) {
            return;
        }
        UIConfiguration conf = mProject.getUIConfig();
        if (conf.getActiveEditorPage() == page) {
            return;
        }

        conf.setActiveEditorPage(page);

        switch (page) {
            case FILTER_EFFECT:
            case AUDIO_MIX:
                conf.setVideoRenderMode(page);
                break;
            default:
                break;
        }
    }

    private final EditParticipant[] _ParticipantList = new EditParticipant[UIEditorPage.values().length];

    public EditParticipant getActivePart() {
        UIEditorPage page = mProject.getUIConfig().getActiveEditorPage();
        return _ParticipantList[page.index()];
    }

    public EditParticipant getPart(UIEditorPage page) {
        return _ParticipantList[page.index()];
    }

    public void setPart(UIEditorPage page, EditParticipant part) {
        _ParticipantList[page.index()] = part;
        part.setActive(false);
    }
}
