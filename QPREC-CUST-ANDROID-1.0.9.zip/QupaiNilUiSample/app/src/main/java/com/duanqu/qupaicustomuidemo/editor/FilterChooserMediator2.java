package com.duanqu.qupaicustomuidemo.editor;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.GridLayoutManagerQuirksFixed;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import com.duanqu.qupai.asset.AssetID;
import com.duanqu.qupai.asset.AssetInfo;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.asset.AssetRepository.Kind;
import com.duanqu.qupai.editor.ProjectClient;
import com.duanqu.qupai.media.android.ProjectPlayerControl;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.UIEditorPageProxy;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupaicustomuidemo.Render.RenderConf;

public class FilterChooserMediator2 extends EditParticipant
implements AssetListAdapter.OnItemClickListener {
    public static final int TYPE_SMOOTH_TO_LEFT = 0;
    public static final int TYPE_SMOOTH_TO_RIGHT = 1;

    private final RecyclerView   _ListView;
    private final AssetListAdapter _FilterAdapter;

    private final Project mProject;

    private TextView _EffectText;
    private TextView _LeftEffectText;
    private TextView _CenterEffectText;
    private TextView _RightEffectText;
    private EffectTextViewAnimator _Animator;

    private int currentSelectIndex = 0;
    private EditorSession mEditorSession;
    private RenderConf mRenderConf;
    private ProjectPlayerControl mPlayerController;

    public FilterChooserMediator2(RecyclerView view, Project project,
                                  AssetRepository repo, EditorSession editorSession,
                                  RenderConf renderConf,ProjectPlayerControl playerController) {
        _ListView = view;
        mEditorSession = editorSession;
        mRenderConf = renderConf;
        mPlayerController = playerController;
        _ListView.setItemAnimator(null);
        mProject = project;

        LinearLayoutManager _LayoutManager = new LinearLayoutManager(_ListView.getContext(), LinearLayoutManager.HORIZONTAL, false);
        _ListView.setLayoutManager(_LayoutManager);

        _FilterAdapter = new AssetListAdapter(null,true);
        _FilterAdapter.setData(repo.find(Kind.FILTER));
        _FilterAdapter.setOnItemClickListener(this);
        _FilterAdapter.setNullTitle(R.string.qupai_ve_none);
        _FilterAdapter.set_NullImage(R.drawable.ic_qupai_yuanpian);

        _ListView.setAdapter(_FilterAdapter);

        AssetID asset_id = mProject.getColorEffect();

        setCheckedItem(asset_id);
    }

    public void setEffectTextView(TextView textView, TextView leftText,
                                  TextView centerText, TextView rightText) {
        _EffectText = textView;
        _LeftEffectText = leftText;
        _CenterEffectText = centerText;
        _RightEffectText = rightText;

        if(_Animator == null) {
            _Animator = new EffectTextViewAnimator(_EffectText, _LeftEffectText,
                    _CenterEffectText, _RightEffectText);
        }
    }

    private void setCheckedItem(AssetID assset_id) {
        int position = _FilterAdapter.setActiveDataItem(assset_id);

        _ListView.scrollToPosition(position);
    }

    @Override
    public boolean onItemClick(AssetListAdapter adapter, int adapter_position) {
        AssetInfo item = _FilterAdapter.getItem(adapter_position);
        currentSelectIndex = adapter_position;
        mProject.setColorEffect(item == null ? null : item.getAssetID());
        updatePlayer();

        return true;
    }

    private void updatePlayer() {
        //生成视频参数json
        String videoContent = mEditorSession.getVideoContent();

        //生成音频参数json
        String soundContent = mEditorSession.getSoundContent();

        //获取project保存目录
        String baseUrl = mRenderConf.getBaseURL();
        Log.d("EditorSession", "videoContent = " + videoContent);
        Log.d("EditorSession", "soundContent = " + soundContent);
        Log.d("EditorSession", "baseUrl = " + baseUrl);
        mPlayerController.setContent(videoContent, soundContent, baseUrl);
        mPlayerController.startAt(0);
    }

}
