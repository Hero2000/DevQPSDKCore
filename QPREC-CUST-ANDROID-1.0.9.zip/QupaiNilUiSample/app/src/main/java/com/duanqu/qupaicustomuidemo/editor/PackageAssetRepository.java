package com.duanqu.qupaicustomuidemo.editor;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;

import com.duanqu.qupai.asset.AssetBundle;
import com.duanqu.qupai.asset.AssetGroup;
import com.duanqu.qupai.asset.AssetID;
import com.duanqu.qupai.asset.AssetInfo;
import com.duanqu.qupai.asset.AssetRepository;
import com.duanqu.qupai.asset.DownloadManager;
import com.duanqu.qupai.asset.RepositoryEditor;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;

public class PackageAssetRepository extends AssetRepository {

    private static final String TAG = "asset-repo";

    public static final class FilterItem {

        public String resourceUrl;
        public int id;
        public String name;

    }

    public PackageAssetRepository(AssetManager assets) {

        for (FilterItem item : loadFilterList(assets)) {
            addFilter(item.id, item.resourceUrl, item.name);
        }

    }

    @Nonnull
    private static FilterItem[] loadFilterList(AssetManager assets) {

        InputStream istream;
        try {
            istream = assets.open("Qupai/filter_list.json");
        } catch (IOException e) {
            Log.e(TAG, "filter list manifest not found", e);
            return new FilterItem[0];
        }


        try {
            return new ObjectMapper().readValue(istream, FilterItem[].class);
        } catch (IOException e) {
            Log.e(TAG, "failed to load filter list manifest", e);
            return new FilterItem[0];
        } finally {
            try {
                istream.close();
            } catch (IOException e) {
            }
        }

    }

    private void addFilter(int id, String path, String title) {
        _FilterList.add(new VideoEditBean(
                VideoEditBean.TYPE_SHADER_EFFECT, id,
                title, "assets://Qupai/" + path,
                VideoEditBean.RECOMMEND_LOCAL, true));
    }

//    public void addMusic(int id, String name, String title) {
//        _MusicList.add(new VideoEditBean(
//                VideoEditBean.TYPE_MUSIC, id,
//                title, "assets://Qupai/music/" + name,
//                VideoEditBean.RECOMMEND_LOCAL, true));
//    }

    public void addMusic(int id,String name,String path){
        _MusicList.add(new VideoEditBean(
                VideoEditBean.TYPE_MUSIC, id,
                name, path,
                VideoEditBean.RECOMMEND_LOCAL, true));
    }

    @Override
    public AssetInfo resolveAsset(AssetID asset_id) {
        long uid = asset_id.getUID();
        switch (asset_id.type) {
            case VideoEditBean.TYPE_SHADER_EFFECT:
                return resolveFilter(uid);
            case VideoEditBean.TYPE_MUSIC:
                return resolveMusic(uid);
            default:
                return null;
        }
    }

    private final ArrayList<VideoEditBean> _FilterList = new ArrayList<>();
    private final ArrayList<VideoEditBean> _MusicList = new ArrayList<>();

    @Override
    public List<? extends AssetInfo> find(Kind kind) {
        switch (kind) {
            case FILTER:
                return _FilterList;
            case SOUND:
                return _MusicList;
        }
        return null;
    }

    private AssetInfo resolveFilter(long uid) {
        for (AssetInfo info : _FilterList) {
            if (info.getUID() == uid) {
                return info;
            }
        }
        return null;
    }

    private AssetInfo resolveMusic(long uid) {
        for (AssetInfo info : _MusicList) {
            if (info.getUID() == uid) {
                return info;
            }
        }
        return null;
    }

    @Override
    public AssetBundle resolveAssetBundle(AssetID asset_id) {
        return (AssetBundle) resolveAsset(asset_id);
    }

    @Override
    public AssetInfo find(Kind diy, long id) {
        return null;
    }

    private final ArrayList<AssetInfo> _List = new ArrayList<>();

    @Override
    public DownloadManager getDownloadManager() {
        return null;
    }

    @Override
    public RepositoryEditor getEditor() { return null; }

    @Override
    public List<? extends AssetGroup> findCategory() {
        return null;
    }

    @Override
    public List<? extends AssetGroup> findSubCategory(@Nonnull int subCategoryId) {
        return null;
    }

    @Override
    public SparseArray<List<? extends AssetInfo>> findSubCategoryContent(List<? extends AssetGroup> group) {
        return null;
    }

    @Override
    public void shareToWX(Context context, String tiltle, String thumbnailUrl, String shareUrl, String desc, int category, long id) {

    }



}
