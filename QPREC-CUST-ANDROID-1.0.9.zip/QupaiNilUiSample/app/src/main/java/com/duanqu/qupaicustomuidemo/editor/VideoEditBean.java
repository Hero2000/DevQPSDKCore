package com.duanqu.qupaicustomuidemo.editor;

import com.duanqu.qupai.asset.AssetBundle;
import com.duanqu.qupai.asset.AssetInfo;
import com.duanqu.qupai.bean.DynamicImage;

import java.io.File;
import java.io.Serializable;

import static com.duanqu.qupai.utils.Assert.fail;


public class VideoEditBean extends AssetInfo implements AssetBundle, Serializable {

    private static final long serialVersionUID = 6384992611872514089L;

	/**
	 * 来源：服务端推荐
	 */
	public static final int RECOMMEND_SERVER = 0;
	/**
	 * 来源：更多下载
	 */
	public static final int RECOMMEND_DOWNLOAD = 1;
	/**
	 * 来源：包内资源
	 */
	public static final int RECOMMEND_LOCAL = 2;
	/**
	 * 来源：服务端删除的推荐资源
	 */
	public static final int RECOMMEND_SERVER_DELETE = 3;
	/**
	 * 来源：客户端删除的推荐资源
	 */
	public static final int RECOMMEND_CLIENT_DELETE = 4;

    /**
     * 字体类型：普通 （字体中包含简繁编码）
     */
    public static final int FONT_TYPE_NORMAL = 1;

    /**
     * 字体类型：繁体 （字体中只包含繁体编码）
     */
    public static final int FONT_TYPE_COMPLEX = 3;

    /**
     * 字体类型：简体 （字体中只包含简体编码）
     */
    public static final int FONT_TYPE_FAMILIAR = 2;

    /**
     * 特殊处理分类：贱萌
     */
    public static final int CATEGORY_SPECIAL_BUD = 4;
    /**
     * 特殊处理分类：可爱
     */
    public static final int CATEGORY_SPECIAL_PRETTY = 3;
    /**
     * 特殊处理分类：可爱
     */
    public static final int CATEGORY_SPECIAL_BUBBLE = 201;
    /**
     * 特殊处理分类：限时推荐
     */
    public static final int CATEGORY_SPECIAL_TIMELIMIT = 80;

    /**
     * 特殊处理分类：限时推荐
     */
    public static final int CATEGORY_SPECIAL_OTHER = -1;

	private final long videoId;

    @Override
    public long getID() {
        return videoId;
    }

	private String videoName;

	@Override
    public String getTitle() {
	    return videoName;
	}

    @Override
    public int getVersion() { return mvVersion; }

    private String videoEditSource;

	public int mvVersion;

	/**是否是推荐的资源*/
    public int recommend;

    /** 是否已经下载 */
    public boolean isLocal;

    @Override
    public boolean isAvailable() { return isLocal; }

    /**是否显示new*/
    public boolean isShow;

    /**资源状态 热门，普通，解锁*/
    public int status;

    /**是否显示下载*/
    public boolean _DownLoading;

    public boolean isAutoDownload;

    public boolean isCategoryCouldUse = true;

    public int specialFontStatus;

    public int categoryId;

    public int fonttype;

    @Override
    public int getGroupID() { return categoryId; }

    public boolean isDownloadable() { return !isLocal && !_DownLoading; }

    public boolean isDownloadMasked(){
        return !(isCategoryCouldUse || !isDownloadable());
    }

    private String _RemoteIconURL;

    private String _RemoteBannerURL;

    public void setRemoteIconURL(String url) {
        _RemoteIconURL = url;
    }

    public void setRemoteBannerURL(String url) {
        _RemoteBannerURL = url;
    }

	//是否锁定
	public boolean isLocked;

    public String shareIcon;
    public String shareTitle;
    public String shareText;
    public String shareUrl;

	public String resourceUrl;//资源包路径

	public final int type;

	public VideoEditBean(int _type, long videoId, String videoName, String videoEditSource, int recommend, boolean isLocal) {
	    type = _type;

		this.videoId = videoId;
		this.videoName = videoName;
		this.recommend=recommend;
		this.isLocal=isLocal;

		setContentString(videoEditSource);
	}

	public void setTitle(String title){
		videoName = title;
	}

    public void setContentPath(File file) {
        videoEditSource = "file://" + file.getAbsolutePath();
    }

    public void setContentString(String str) {

        if (str == null || str.startsWith("assets://") || str.startsWith("file://")) {

        	videoEditSource = str;
            return;
        }

        switch (type) {
        case TYPE_MUSIC:
        case TYPE_DIYOVERLAY:
        case TYPE_SHADER_MV:
        case TYPE_MV_MUSIC:
        case TYPE_FONT:
            switch (recommend) {
            case RECOMMEND_LOCAL:
                videoEditSource = "assets://" + str;
                break;
            default:
                videoEditSource = "file://" + str;
                break;
            }
            break;
//        case TYPE_SHADER_MV:
//        case TYPE_MV_MUSIC:
//            videoEditSource = str;
//            break;
        default:
            fail();
        }
    }

    @Override
    public String getContentURIString() {
        return videoEditSource;
    }

    @Override
    public String getIconURIString() {
        if (!isLocal || (type != TYPE_FONT && recommend == 0)) {
        	if(_RemoteIconURL.startsWith("http://")){
        		return _RemoteIconURL;
        	}
        }

        switch (type) {
        case TYPE_MV_MUSIC:
            return videoEditSource + "/icon_music.png";
        case TYPE_MUSIC:
            return videoEditSource + "/icon_without_name.png";
        case TYPE_FONT:
            return videoEditSource + "/icon2.png";
        default:
            return videoEditSource + "/icon.png";
        }
    }

    @Override
    public String getBannerURIString() {
        if (!isLocal || recommend == 0) {
            if(_RemoteBannerURL.startsWith("http://")){
                return _RemoteBannerURL;
            }
        }

        switch (type) {
            case TYPE_FONT:
                return videoEditSource + "/banner.png";
            default:
                return videoEditSource + "/icon.png";
        }
    }

    @Override
    public long getUID() {
        return ((long) type << 32) + videoId;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public String getMediaURIString() {
        switch (type) {
        case TYPE_MUSIC:
            return videoEditSource + "/audio.mp3";
        case TYPE_MV_MUSIC:
            return videoEditSource + "/music.mp3";
        case TYPE_DIYOVERLAY:
            return videoEditSource + "/content.mkv";
        case TYPE_FONT:
            return DynamicImage.TEXTONLYCONFIG + "/content.mkv";
        default:
            return null;
        }
    }

    @Override
    public String getMediaURIString(String name) {
        return videoEditSource + "/" + name;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof VideoEditBean){
            VideoEditBean veb = (VideoEditBean) o;
            return videoId == veb.videoId;
        }
        return false;
    }

    @Override
    public boolean isNeedSpecialFont() {
        return false;//TODO 业务相关
    }

    @Override
    public String getSceneURL() {
        return null;
    }

    @Override
    public AssetBundle getContent() { return this; }

    @Override
    public int getFlags() { return (isLocked ? FLAG_LOCKED : 0) | (isShow ? FLAG_NEW : 0); }

    @Override
    public int getResourceStatus() {
        return status;
    }

    @Override
    public String getResourceUrl() {
        return resourceUrl;
    }
}
