package com.duanqu.qupaicustomuidemo.session;

import android.content.Context;

import com.duanqu.qupai.engine.session.SessionClientFactory;
import com.duanqu.qupai.engine.session.VideoSessionClient;
import com.duanqu.qupaicustomuidemo.TestApplication;

import java.io.Serializable;

public class VideoSessionClientFactoryImpl extends SessionClientFactory {

    @Override
    public VideoSessionClient createSessionClient(Context context, Serializable data) {
        TestApplication app = (TestApplication) context.getApplicationContext();
        return app.videoSessionClient;
    }

}
