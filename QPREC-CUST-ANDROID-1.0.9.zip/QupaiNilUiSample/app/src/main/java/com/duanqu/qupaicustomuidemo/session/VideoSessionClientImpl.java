package com.duanqu.qupaicustomuidemo.engine.session;

import android.content.Context;

import com.duanqu.qupai.engine.session.ProjectOptions;
import com.duanqu.qupai.engine.session.VideoSessionClient;
import com.duanqu.qupai.engine.session.VideoSessionCreateInfo;
import com.duanqu.qupai.jackson.JSONSupportImpl;
import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.project.WorkspaceClient;
import com.duanqu.qupaicustomuidemo.uicomponent.SimpleWorkspace;
import com.duanqu.qupaicustomuidemo.editor.PackageAssetRepository;

public class VideoSessionClientImpl extends VideoSessionClient {
    private final PackageAssetRepository _AssetRepo;
    private Context context;
    private final JSONSupport _JSON;
    private ProjectOptions _ProjectOptions;

    public VideoSessionClientImpl(Context app) {
        context = app;
        _AssetRepo = new PackageAssetRepository(context.getAssets());
        _JSON = new JSONSupportImpl();
    }

    @Override
    public PackageAssetRepository getAssetRepository() {
        return  _AssetRepo;
    }

    @Override
    public JSONSupport getJSONSupport() {
        return _JSON;
    }

    @Override
    public ProjectOptions getProjectOptions() {
        return _ProjectOptions;
    }

    public void setProjectOptions(ProjectOptions _ProjectOptions) {
        this._ProjectOptions = _ProjectOptions;
    }

    private VideoSessionCreateInfo _CreateInfo;

    public void setCreateInfo(VideoSessionCreateInfo info) {
        _CreateInfo = info;
    }

    @Override
    public VideoSessionCreateInfo getCreateInfo() {
        return _CreateInfo;
    }

    @Override
    public WorkspaceClient createWorkspace(Context context) {
        return new SimpleWorkspace(context,_JSON);
    }
}
