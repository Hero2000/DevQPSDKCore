package com.duanqu.qupaicustomuidemo.trim;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.duanqu.qupai.android.widget.AspectRatioLayout;
import com.duanqu.qupai.stage.android.BitmapLoader;
import com.duanqu.qupai.stage.android.Stage;
import com.duanqu.qupai.stage.android.StageHost;
import com.duanqu.qupai.stage.android.SurfaceHolderLink;
import com.duanqu.qupaicustomuidemo.R;
import java.io.File;

public class ImportActivity extends Activity implements View.OnClickListener{
    private static final int REQUEST_CODE_PICK_INPUT = 0;
    EditText video_path;
    Button btn_import;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import);

        video_path = (EditText)findViewById(R.id.txt_video_in_path);
        btn_import = (Button)findViewById(R.id.btn_import);

        video_path.setOnClickListener(this);
        btn_import.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.txt_video_in_path:
                //仅仅是demo导入. 自己做可以区分 MP4,3gp等视频.
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                intent.setType("video/*");
                startActivityForResult(intent, REQUEST_CODE_PICK_INPUT);
            break;
            case R.id.btn_import:
                //demo获取，如果自己做建议使用MediaStore的方式获取
                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                //use one of overloaded setDataSource() functions to set your data source
                retriever.setDataSource(v.getContext(), Uri.fromFile(new File(video_path.getText().toString())));
                String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                int timeInMillisec = Integer.parseInt(time);

                Intent intentTrim = new Intent(v.getContext(),TrimActivity.class);
                intentTrim.putExtra("importVideoPath",video_path.getText().toString());
                intentTrim.putExtra("duration",timeInMillisec);
                startActivity(intentTrim);
            break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_CODE_PICK_INPUT:
            if (resultCode == RESULT_OK) {
                video_path.setText(resolvePath(data.getData()));
            }
                break;
        }
    }

    private String resolvePath(Uri uri) {
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        } else if ("content".equals(uri.getScheme())) {
            String[] projection = {MediaStore.Video.Media.DATA};
            Cursor cursor = MediaStore.Video.query(getContentResolver(), uri, projection);
            int column_index = cursor.getColumnIndexOrThrow(projection[0]);
            cursor.moveToFirst();
            String path = cursor.getString(column_index);
            cursor.close();
            return path;
        } else {
            return "";
        }
    }
}
