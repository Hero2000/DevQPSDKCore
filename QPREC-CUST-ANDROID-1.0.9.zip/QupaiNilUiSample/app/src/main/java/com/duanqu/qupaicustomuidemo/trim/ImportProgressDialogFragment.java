package com.duanqu.qupaicustomuidemo.trim;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

import com.duanqu.qupai.dialog.ProgressDialogFragment;
import com.duanqu.qupai.jackson.JSONSupportImpl;
import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.project.Clip;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.ProjectConnection;
import com.duanqu.qupai.project.ProjectConnection.OnChangeListener;
import com.duanqu.qupai.project.UIMode;
import com.duanqu.qupai.trim.FilterProfile;
import com.duanqu.qupai.trim.ImportTask;
import com.duanqu.qupai.widget.android.app.ProgressDialog;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupaicustomuidemo.editor.EditorActivity;
import com.duanqu.qupaicustomuidemo.session.RenderRequest;
import com.duanqu.qupaicustomuidemo.session.VideoSessionClientFactoryImpl;
import com.duanqu.qupaicustomuidemo.uicomponent.SimpleWorkspace;

public class ImportProgressDialogFragment extends ProgressDialogFragment
        implements ImportTask.OnProgressListener, ImportTask.OnCompletionListener {

    private static final String TAG = "ImportProgressDFragment";

    public static class Builder extends ProgressDialogFragment.Builder {

        private static final String KEY_TRIM = "TRIM";

        private static final String KEY_CONTENT_RECT = "CONTENT_RECT";

        private static final String KEY_INPUT_PATH = "INPUT_PATH";

        public Builder() {
            setMax(100);
            setMessage(R.string.qupai_transcode_in_progress);
            setProgressStyle(ProgressDialog.STYLE_SPINNER);
            setAnimatedRotateContent(R.drawable.progress_recorder_qupai_content);
        }

        public Builder setTrim(long from, long to) {
            _Bundle.putLongArray(KEY_TRIM, new long[]{from, to});
            return this;
        }

        public static long[] getTrim(Bundle args) {
            return args.getLongArray(KEY_TRIM);
        }

        public Builder setContentRect(int left, int top, int right, int bottom) {
            _Bundle.putIntArray(KEY_CONTENT_RECT, new int[]{left, top, right, bottom});
            return this;
        }

        public static int[] getContentRect(Bundle args) {
            return args.getIntArray(KEY_CONTENT_RECT);
        }

        public Builder setInputPath(String input_path) {
            _Bundle.putString(KEY_INPUT_PATH, input_path);
            return this;
        }

        public static String getInputPath(Bundle args) {
            return args.getString(KEY_INPUT_PATH);
        }

        @Override
        protected ImportProgressDialogFragment newInstance() {
            return new ImportProgressDialogFragment();
        }

    }

    private ImportTask importTask;
    private String outPutPath;

    private ProjectConnection _ClipManager;

    private static int task_count = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        JSONSupport json = new JSONSupportImpl();
        //创建一个ProjectConnection 用于保存project到本地
        _ClipManager = new ProjectConnection(new SimpleWorkspace(getActivity(), json));

        _ClipManager.addOnChangeListener(new OnChangeListener() {
            @Override
            public void onChange(ProjectConnection pc, Project project) {

                if (project == null) {
                    requestTaskStart();
                }
            }
        });

        setStyle(STYLE_NO_FRAME, R.style.Theme_Dialog_Recorder);
    }

    @Override
    public ProgressDialog onCreateDialog(Bundle savedInstanceState) {
        ProgressDialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    @Override
    public void onResume() {
        super.onResume();

        requestTaskStart();
    }

    @Override
    public void onPause() {

        requestTaskStop(true);

        super.onPause();
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);

        TrimActivity activity = (TrimActivity) getActivity();
        if (activity != null) {
            activity.onImportDialogDismiss();
        }
    }
    private long _TrimEnd = 0;
    private  long _TrimStart = 0;
    private void requestTaskStart() {

        if (importTask != null || !isResumed()) {
            return;
        }

        if (_ClipManager.getProjectUri() != null) {
            _ClipManager.removeProject();
            return;
        }

        Bundle args = getArguments();

        //得到输入文件地址
        String input = Builder.getInputPath(args);
        //得到裁剪时间参数
        long[] trim = Builder.getTrim(args);
        //得到裁剪位置矩阵
        int[] content_rect = Builder.getContentRect(args);

        importTask = new ImportTask();
        //left0, top1, right2, bottom3
        //宽=left-right
        //高=bottom-top
        int width = content_rect[2] - content_rect[0];
        int height = content_rect[3] - content_rect[1];

        //分辨率需要偶数
        width = (width % 2 == 1) ? width - 1 : width;
        height = (height % 2 == 1) ? height - 1 : height;

        //创建一个project 并且传递宽高出去
        int w = 480;
        int h = (int) (w * ((float) height / (float) width));

        h = (h % 2 == 1) ? h - 1 : h;
        _ClipManager.createNewProject(Project.TYPE_VIDEO, w, h);
        Log.e(TAG, "task count " + (++task_count));
        outPutPath = _ClipManager.newFilename(".mov");
        importTask.setSourceURL(input);
        importTask.setOutputURL(outPutPath);
        importTask.setAudioEncoder("libfdk_aac");//pcm_s16le
        importTask.setVideoEncoder("mini264");
        importTask.setGop(180);
        importTask.setFps(30);
        importTask.setBps(1000);
        /**
         * 获取解码的宽高
         */
        FilterProfile profile = new FilterProfile();
        _TrimEnd = trim[1];
        _TrimStart = trim[0];
        //裁剪时间
        profile.trim(trim[0] / 1000000f, trim[1] / 1000000f);
        profile.atrim(trim[0] / 1000000f, trim[1] / 1000000f);
        importTask.setDuration(trim[0]/1000, trim[1]/1000);
        importTask.setRotate(importTask.getAngle());
        //得到输出的宽高
        final int output_width = _ClipManager.getProject().getCanvasWidth();
        final int output_height = _ClipManager.getProject().getCanvasHeight();

        width = importTask.getWidth() < width ? importTask.getWidth():width;
        height = importTask.getHeight() < height ? importTask.getHeight() : height;
        float ratio = (float)output_width/(float)width;


        //设置输出宽高--裁剪的宽高小于输出的宽高
        if (width <= output_width || height <= output_height) {
            importTask.setOutputSize(width, height, importTask.getAngle());
            importTask.setCrop(content_rect[0],content_rect[1]);
        } else {
            importTask.setOutputSize(output_width, output_height, 0);
            int scaleWidth,scaleHeight;
            if(importTask.getAngle() == 90 || importTask.getAngle() == 270)
            {
                scaleWidth = (int )(importTask.getHeight()*ratio);
                scaleHeight = (int)(importTask.getWidth()*ratio);
            }
            else
            {
                scaleWidth = (int )(importTask.getWidth()*ratio);
                scaleHeight = (int)(importTask.getHeight()*ratio);
            }

            if(scaleHeight %2 != 0)
                scaleHeight++;
            if(scaleWidth%2 != 0)
                scaleWidth++;
            importTask.setScale(scaleWidth,scaleHeight);
            int x = (int)(content_rect[0]*ratio);
            int y = (int)(content_rect[1]*ratio);
            importTask.setCrop(x,y);
        }
        importTask.setVideoFilterProfile(profile.getVideoProfile());
        importTask.setAudioFilterProfile(profile.getAudioProfile());
        importTask.setCompletionListener(this);
        importTask.setProgressListener(this);

        if (importTask.realize() != 0) {
            Log.e(TAG, "failed to start importer");
            Toast toast2 = Toast.makeText(getActivity(),
                    getResources().getText(R.string.qupai_trim_open_video_failed), Toast.LENGTH_SHORT);
            toast2.setGravity(Gravity.CENTER, 0, 0);
            toast2.show();

            importTask.dispose();
            importTask = null;
            dismiss();
            return;
        }

        importTask.start();
    }

    private void requestTaskStop(boolean cancel) {

        if (importTask == null) {
            return;
        }

        if (cancel) {
            importTask.cancel();
        }

        importTask.stop();
        long duration = importTask.getDuration();
        int angle = 0 ;//importTask.getAngle();
        importTask.dispose();
        importTask = null;
        Log.e(TAG, "task count " + (--task_count));

        if (cancel) {
            return;
        }


        Clip bean = new Clip();
        bean.src = outPutPath;
        //判断旋转角度传递一个矩阵
        Matrix m = new Matrix();
        if (angle == 90 || angle == 270) {
            bean.width = _ClipManager.getProject().getCanvasHeight();
            bean.height = _ClipManager.getProject().getCanvasWidth();
            m.postRotate(angle, bean.width / 2, bean.height / 2);
            float tx = (float) (bean.height - bean.width) / 2;
            m.postTranslate(tx, -tx);
        } else {
            bean.width = _ClipManager.getProject().getCanvasWidth();
            bean.height = _ClipManager.getProject().getCanvasHeight();
            m.postRotate(angle, bean.width / 2, bean.height / 2);
        }

        bean.setDurationMilli(duration / 1000);
        bean.setDisplayMatrix(m);

        _ClipManager.addClip(bean);
        _ClipManager.saveProject(UIMode.EDITOR);

        Intent in = new Intent();
        in.setData(_ClipManager.getProjectUri());

        new EditorActivity.Request(new VideoSessionClientFactoryImpl(), null)
                .setProjectUri(_ClipManager.getProject().getUri())
                .startForResult(getActivity(), RenderRequest.RENDER_MODE_EXPORT_VIDEO);

    }

    private static final int IMPORT_TASK = 0;

    private static Handler _TaskHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case IMPORT_TASK:
                    ((ImportProgressDialogFragment) (msg.obj)).requestTaskStop(false);
                    ((ImportProgressDialogFragment) (msg.obj)).dismiss();
                    break;
                default:
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    public void onCompletion(ImportTask task) {

        Message msg = Message.obtain(_TaskHandler, IMPORT_TASK, this);
        msg.sendToTarget();

    }

    @Override
    public void onProgress(ImportTask task, long time) {
        Log.i(TAG, "progress: " + time);
        Log.i(TAG, "progress: " + time);
        long progress = (time-_TrimStart) * 100 / (_TrimEnd-_TrimStart);
        if(progress <0)
            progress = 0;
        else if(progress > 100)
            progress = 100;
        setProgress((int) progress);
    }


}
