package com.duanqu.qupaicustomuidemo.uicomponent;

public interface BeautySkin {

    void enableBeautySkin(boolean enable);

    boolean isBeautySkinEnabled();

    void setBeautySkinDegree(int degree);

    int getBeautySkinDegree();

}
