package com.duanqu.qupaicustomuidemo.uicomponent;

import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import com.duanqu.qupaicustomuidemo.R;

public class BeautySkinSlider implements BeautySkinSwitch.OnBeautyEnabledListener {

    private int mProgress;
    private View       mRoot;
    private SeekBar    mSeekBar;
    private TextView   mShowRatio;
    private BeautySkin mBeautySkin;

    public BeautySkinSlider(View root, BeautySkin beautySkin) {

        //TextView, 显示美颜百分比
        mProgress = beautySkin.getBeautySkinDegree();
        mShowRatio = (TextView) root.findViewById(R.id.photo_process);
        mShowRatio.setText(mProgress + "%");

        //SeekBar 调整美颜级别
        mSeekBar = (SeekBar) root.findViewById(R.id.photo_skinSeekBar);
        mSeekBar.setProgress(mProgress);
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mProgress = Math.max(0, mProgress);
                mProgress = Math.min(mProgress, 100);
                mBeautySkin.setBeautySkinDegree(mProgress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mProgress = progress;
                mShowRatio.setText(progress + "%");
            }
        });

        mRoot = root;
        mBeautySkin = beautySkin;
    }

    @Override
    public void onBeautyEnabled(boolean enable) {
        if(enable) {
            mRoot.setVisibility(View.VISIBLE);
        } else {
            mRoot.setVisibility(View.GONE);
        }
    }
}
