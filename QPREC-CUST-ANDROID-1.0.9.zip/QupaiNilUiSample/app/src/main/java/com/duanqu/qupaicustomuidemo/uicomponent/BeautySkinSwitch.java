package com.duanqu.qupaicustomuidemo.uicomponent;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.duanqu.qupaicustomuidemo.R;
import com.duanqu.qupai.render.BeautyRenderer;

import java.util.ArrayList;

public class BeautySkinSwitch
        implements View.OnClickListener, BeautySkin {

    private View mView;
    private int mBeautySkinDegree              = 80;
    private boolean mBeautySkinEnabledCurrent  = false;
    private boolean mBeautySkinEnabledSaved    = false;
    private BeautyRenderer mBeautyRenderer;

    interface OnBeautyEnabledListener{
        void onBeautyEnabled(boolean enable);
    }
    private ArrayList<OnBeautyEnabledListener> mListeners = new ArrayList<>();

    public BeautySkinSwitch(View view, BeautyRenderer renderer) {

        view.setOnClickListener(this);
        mView = view;

        renderer.setBeautyOn(mBeautySkinEnabledCurrent);
        renderer.updateProgress(mBeautySkinDegree);
        mBeautyRenderer = renderer;
    }

    public void addOnBeautyEnabledListener(OnBeautyEnabledListener l) {
        if(!mListeners.contains(l)) {
            mListeners.add(l);
        }
    }

    public void removeOnBeautyEnabledListener(OnBeautyEnabledListener l) {
        if(mListeners.contains(l)) {
            mListeners.remove(l);
        }
    }

    @Override
    public void onClick(View view) {
        enableBeautySkin(!mBeautySkinEnabledCurrent);
    }

    @Override
    public void enableBeautySkin(boolean enable) {

        mView.setActivated(enable);
        mBeautyRenderer.setBeautyOn(enable);
        mBeautySkinEnabledCurrent = enable;

        for(OnBeautyEnabledListener l : mListeners) {
            l.onBeautyEnabled(enable);
        }

        update();
    }

    @Override
    public boolean isBeautySkinEnabled() {
        return mBeautySkinEnabledCurrent;
    }

    @Override
    public void setBeautySkinDegree(int degree) {
        mBeautySkinDegree = degree;
        mBeautyRenderer.updateProgress(mBeautySkinDegree);
    }

    @Override
    public int getBeautySkinDegree() {
        return mBeautySkinDegree;
    }

    /* update icon display and others */
    private void update() {
        if(mBeautySkinEnabledCurrent) {
            Drawable anim = mView.getBackground();
            if (anim instanceof AnimationDrawable) {
                if (anim != null && ((AnimationDrawable) anim).isRunning()) {
                    ((AnimationDrawable) anim).stop();
                }
            }

            mView.setBackgroundResource(0);
        } else {
            mView.setBackgroundResource(R.drawable.anim_beauty_icon_show);
            Drawable anim = mView.getBackground();
            if (anim instanceof AnimationDrawable) {
                if (!((AnimationDrawable) anim).isRunning()) {
                    ((AnimationDrawable) anim).start();
                }
            }
        }
    }
}