package com.duanqu.qupaicustomuidemo.uicomponent;

import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import com.duanqu.qupaicustomuidemo.R;

public class BeautySkinTips_TextView implements BeautySkinSwitch.OnBeautyEnabledListener {

    private TextView mTextView;

    public BeautySkinTips_TextView(TextView view) {
        mTextView = view;
    }

    @Override
    public void onBeautyEnabled(boolean enable) {
        if (enable) {
            mTextView.setText(R.string.qupai_beautyskin_open);
            mTextView.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mTextView.setVisibility(View.INVISIBLE);
                }
            }, 2000);
        } else {
            mTextView.setText(R.string.qupai_beautyskin_close);
            mTextView.setVisibility(TextView.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mTextView.setVisibility(TextView.INVISIBLE);
                }
            }, 2000);
        }
    }
}
