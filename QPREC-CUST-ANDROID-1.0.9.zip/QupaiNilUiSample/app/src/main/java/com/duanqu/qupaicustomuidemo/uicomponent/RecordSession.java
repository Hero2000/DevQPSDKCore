package com.duanqu.qupaicustomuidemo.uicomponent;

import android.util.Log;

import com.duanqu.qupai.android.camera.CameraClient;
import com.duanqu.qupai.camera.PreviewSource9;
import com.duanqu.qupai.media.AudioCapture;
import com.duanqu.qupai.media.Recorder9;
import com.duanqu.qupai.project.Clip;
import com.duanqu.qupai.recorder.ClipManager;
import com.duanqu.qupai.recorder.RecorderTask;

public
class RecordSession{

//    private final View _View;

    private boolean mIsRecording = false;
    private Recorder9 mRecorder = new Recorder9();
    private Clip _CurrentData;
    private ClipManager mClipManager;
    private CameraClient mCameraClient;
    private final AudioCapture _AudioSource = new AudioCapture();
    private Recorder9.OnFeedbackListener mFeedbackListener;

    public RecordSession(ClipManager clip_manager, CameraClient camera_client) {
        mClipManager  = clip_manager;
        mCameraClient = camera_client;
        mRecorder.setFeedbackListener(_FeedbackListener);
    }

    public void onResume() {
        _AudioSource.create();
    }

    public void onPause() {

        requestStop();
        _AudioSource.destroy();
        mRecorder.join();
    }

    public void onDestroy() {
        _AudioSource.release();
        mRecorder.onDestroy();
    }

    /**
     * 开始录制
     * @return
     */
    public boolean requestStart() {
        if(mIsRecording) {
            return false;
        }

        mClipManager.setLastClipSelected(false);
        if (!mClipManager.isReady()) {
            return false;
        }

        mRecorder.enableMediaCodec(false);
        PreviewSource9 video_source = mCameraClient.getSource();
        if (video_source == null || !video_source.isReady()) {
            return false;
        }
        mRecorder.setVideoSource(video_source);

        if (mClipManager.getRemainingDuration() <= 0) {
            return false;
        }

        String output_path = mClipManager.newFilename(".mov");

        if (output_path == null) {
            return false;
        }

        mRecorder.setOutputPath(output_path, "mov");
        mRecorder.setAudioSource(_AudioSource);
        mRecorder.setDurationLimit(mClipManager.getRemainingDuration());

        _CurrentData = mRecorder.startRecord();
        if (_CurrentData == null) {
            return false;
        }
        mClipManager.onRecordStart(_CurrentData);

        Log.w(Recorder9.TAG, "requestRecorderStart OK");

        mIsRecording = true;
        return true;
    }

    /**
     * 停止录制
     */
    public void requestStop() {
        if(!mIsRecording) {
            return;
        }

        mRecorder.stopRecord();
        _CurrentData.setDurationMilli(mRecorder.getClipDuration());
        mClipManager.onRecordStop(_CurrentData);
        mRecorder.setVideoSource(null);
        mRecorder.setRecorder(null);
        mRecorder.setAudioSource(null);
        mIsRecording = false;
    }


    public void setFeedbackListener(Recorder9.OnFeedbackListener listener) {
        this.mFeedbackListener = listener;
    }

    private Recorder9.OnFeedbackListener _FeedbackListener = new Recorder9.OnFeedbackListener() {
        @Override
        public void onLimitReached(Recorder9 rec, long timestamp) {
            if(mFeedbackListener != null) {
                mFeedbackListener.onLimitReached(rec, timestamp);
            }
        }

        @Override
        public void onProgress(Recorder9 rec, long timestamp) {
            mClipManager.onRecordProgress(timestamp);
            if(mFeedbackListener != null) {
                mFeedbackListener.onProgress(rec, timestamp);
            }
        }

        @Override
        public void OnCompletion(Recorder9 rec) {
            if(mFeedbackListener != null) {
                mFeedbackListener.OnCompletion(rec);
            }
        }

        @Override
        public void OnRecorderTaskCompletion(Recorder9 rec, RecorderTask task) {
            String file = task.getVideoFile();
            for (int i = mClipManager.getClipCount() - 1; i >= 0; --i) {
                if (mClipManager.getClip(i).src.equals(file)) {
                    mClipManager.getClip(i).setState(Clip.State.COMPLETED);
                    break;
                }
            }
            if(mFeedbackListener != null) {
                mFeedbackListener.OnRecorderTaskCompletion(rec, task);
            }
        }

        @Override
        public void onError(Recorder9 rec, Throwable tr) {
            if(mFeedbackListener != null) {
                mFeedbackListener.onError(rec, tr);
            }
        }
    };
}
