package com.duanqu.qupaicustomuidemo.uicomponent;

import android.content.Context;
import android.net.Uri;
import com.duanqu.qupai.json.JSONSupport;
import com.duanqu.qupai.project.Project;
import com.duanqu.qupai.project.ProjectInfo;
import com.duanqu.qupai.project.ProjectUtil;
import com.duanqu.qupai.project.WorkspaceClient;
import com.duanqu.qupaicustomuidemo.R;

import java.io.File;

/**
 */
public class SimpleWorkspace implements WorkspaceClient {

    private final File _WorkspaceDir;
    private final JSONSupport _JSON;

    public SimpleWorkspace(Context context, JSONSupport json) {
        _JSON = json;

        File root_dir = context.getExternalFilesDir(null);
        if (root_dir == null) {
            _WorkspaceDir = null;
        } else {
            String dir = context.getString(R.string.qupai_simple_workspace_dir);
            _WorkspaceDir = new File(root_dir, dir);
            _WorkspaceDir.mkdirs();
        }
    }

    @Override
    public boolean isConnected() {
        return _WorkspaceDir != null && _WorkspaceDir.isDirectory();
    }

    @Override
    public boolean attachProject(ProjectInfo info) {
        return false;
    }

    @Override
    public void removeProject(Uri uri) { }

    @Override
    public Project createProject(int type, int width, int height) {
        Project p = new Project();
        p.setProjectDir(_WorkspaceDir, Project.getProjectFile(_WorkspaceDir));
        p.setType(type);
        configureProject(p, width, height);
        return p;
    }

    private void configureProject(Project project){
        configureProject(project, 0, 0);
    }
    private void configureProject(Project project, int width, int height) {
        // FIXME(yuxl) move project io to a separate class
        if (project.getCanvasWidth() == 0 || project.getCanvasHeight() == 0) {
            if(project.getType() == Project.TYPE_VIDEO){
                project.setCanvasSize(width == 0 ? 480 : width,
                        height == 0 ? 480: height);
            }else{
                project.setCanvasSize(width == 0 ? 480 : width,
                        height == 0 ? 480: height);
            }
            //project.setCanvasSize(_Options.legacyVideoWidth, _Options.legacyVideoHeight);
        }
    }

    @Override
    public Project readProject(File file) {
        return ProjectUtil.readProject(file, _JSON);
    }

    @Override
    public void writeProject(Project proj, File file) {
        ProjectUtil.writeProject(proj, file, _JSON);
    }

    @Override
    public void release() { }

}
