package com.duanqu.qupaicustomuidemo.uicomponent;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.duanqu.qupaicustomuidemo.R;

public class TimelineTimeLayout extends ViewGroup {

    public TimelineTimeLayout(Context context) {
        this(context, null);
    }

    public TimelineTimeLayout(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
    }

    public TimelineTimeLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        View child = getChildAt(0);

        child.measure(child.getLayoutParams().width, child.getLayoutParams().height);

        int width = getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec);
        int height = child.getMeasuredHeight();

        super.setMeasuredDimension(width, height);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = r - l;

        View child = getChildAt(0);
        int child_width = child.getMeasuredWidth();
        int child_height = child.getMeasuredHeight();

        int progress = (int) (width * _Progress);
        int child_left, child_right;
        int child_bg;
        if (progress + child_width < width) {
            child_left = progress;
            child_right = progress + child_width;
            child_bg = R.drawable.recorder_qupai_time_balloon_tip_bg_left;
        } else {
            child_left = progress - child_width;
            child_right = progress;
            child_bg = R.drawable.recorder_qupai_time_balloon_tip_bg_right;
        }
        child.layout(child_left, 0, child_right, child_height);
        child.setBackgroundResource(child_bg);
    }

    private float _Progress;

    public void setProgress(float value) {
        _Progress = value;
        requestLayout();
    }

}
