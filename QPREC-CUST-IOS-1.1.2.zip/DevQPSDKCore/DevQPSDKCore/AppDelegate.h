//
//  AppDelegate.h
//  DevQPSDKCore
//
//  Created by LYZ on 16/4/29.
//  Copyright © 2016年 LYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

