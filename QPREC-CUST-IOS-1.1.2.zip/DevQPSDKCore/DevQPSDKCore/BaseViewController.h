//
//  BaseViewController.h
//  DevQPSDKCore
//
//  Created by LYZ on 16/4/29.
//  Copyright © 2016年 LYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *widthLabel;
@property (weak, nonatomic) IBOutlet UITextField *heightLabel;

@end
