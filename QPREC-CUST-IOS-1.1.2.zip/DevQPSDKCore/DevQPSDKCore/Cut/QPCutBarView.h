//
//  QPCutBarView.h
//  QupaiSDK
//
//  Created by lyle on 14-3-18.
//  Copyright (c) 2014年 lyle. All rights reserved.
//

#import <UIKit/UIKit.h>

@class QPCutInfo;

@interface QPCutBarView : UIView

- (id)initWithFrame:(CGRect)frame cutInfo:(QPCutInfo *)cutInfo;

@end
