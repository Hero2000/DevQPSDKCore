//
//  QPCutThumbnailCell.h
//  QupaiSDK
//
//  Created by lyle on 14-3-17.
//  Copyright (c) 2014年 lyle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QPCutThumbnailCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imageViewIcon;

@end
