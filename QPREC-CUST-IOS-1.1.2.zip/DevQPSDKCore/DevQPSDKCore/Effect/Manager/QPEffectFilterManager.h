//
//  QPEffectFilterManager.h
//  DevQPSDKCore
//
//  Created by Worthy on 16/8/29.
//  Copyright © 2016年 LYZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QPEffectFilter.h"

@interface QPEffectFilterManager : NSObject
- (NSMutableArray *)createFilter;
@end
