//
//  QPEffectMusicManager.h
//  DevQPSDKCore
//
//  Created by Worthy on 16/8/29.
//  Copyright © 2016年 LYZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QPEffectMusic.h"

@interface QPEffectMusicManager : NSObject
- (NSMutableArray *)createMusic;
@end
