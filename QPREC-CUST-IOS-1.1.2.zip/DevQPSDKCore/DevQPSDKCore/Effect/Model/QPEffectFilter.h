//
//  QPEffectFilter.h
//  QupaiSDK
//
//  Created by yly on 15/6/18.
//  Copyright (c) 2015年 lyle. All rights reserved.
//

#import "QPEffect.h"

@class QUMVTemplate;

@interface QPEffectFilter : QPEffect

@property (nonatomic, strong) QUMVTemplate *mvTemplate;
//@property (nonatomic, strong) NSString *mvPath;

@end
