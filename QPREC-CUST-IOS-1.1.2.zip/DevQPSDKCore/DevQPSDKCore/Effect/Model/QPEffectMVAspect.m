//
//  QPEffectMVAspect.m
//  DevQPSDKCore
//
//  Created by Worthy on 16/9/18.
//  Copyright © 2016年 LYZ. All rights reserved.
//

#import "QPEffectMVAspect.h"

@implementation QPEffectMVAspect

@end
