//
//  EffectLoadMoreMusicCell.h
//  qupai
//
//  Created by yly on 14/12/23.
//  Copyright (c) 2014年 duanqu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QPEffectLoadMoreCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIView *viewTop;
@property (nonatomic, weak) IBOutlet UIImageView *imageViewBg;
@property (weak, nonatomic) IBOutlet UILabel *labelName;

@end
