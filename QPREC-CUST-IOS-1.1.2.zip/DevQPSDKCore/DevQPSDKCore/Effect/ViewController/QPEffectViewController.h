//
//  QPEffectViewController.h
//  QupaiSDK
//
//  Created by yly on 15/6/17.
//  Copyright (c) 2015年 lyle. All rights reserved.
//

#import "QPBaseViewController.h"
//#import "QPMediaRender.h"

extern NSString *QPMoreMusicUpdateNotification;

@class QPGPUImageView, QPEffectTabView;

@interface QPEffectViewController : QPBaseViewController<QPMediaRenderDelegate>


@end
