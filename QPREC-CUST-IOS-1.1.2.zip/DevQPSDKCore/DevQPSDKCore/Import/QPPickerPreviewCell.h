//
//  DraftsCell.h
//  duanqu2
//
//  Created by lyle on 14-2-26.
//  Copyright (c) 2014年 duanqu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QPPickerPreviewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imageViewIcon;
@property (nonatomic, strong) UILabel *labelDuration;
@property (nonatomic, strong) UIImageView *imageViewFlag;
@property (nonatomic, strong) UIImageView *maskerImage;

@end
