//
//  QPBundle.h
//  QupaiSDK
//
//  Created by yly on 15/6/17.
//  Copyright (c) 2015年 lyle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QPBundle : NSBundle

+ (NSBundle *)qp_bundle;
//+ (NSBundle *)mainBundle;

@end
