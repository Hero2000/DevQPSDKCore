//
//  QPString.h
//  QupaiSDK
//
//  Created by yly on 15/6/18.
//  Copyright (c) 2015年 lyle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QPString : NSString

+ (CGSize)sizeWithFontSize:(CGFloat)size text:(NSString *)text;

@end
