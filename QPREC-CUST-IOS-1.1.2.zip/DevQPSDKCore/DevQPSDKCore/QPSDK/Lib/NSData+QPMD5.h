//
//  NSData+QPMD5.h
//  ALBBQuPaiPlugin
//
//  Created by zhangwx on 16/1/4.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (QPMD5)
- (NSString*)md5;
@end
