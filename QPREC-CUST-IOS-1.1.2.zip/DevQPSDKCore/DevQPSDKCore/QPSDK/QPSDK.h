//
//  QPSDK.h
//  QPSDK
//
//  Created by yly on 16/3/22.
//  Copyright © 2016年 lyle. All rights reserved.
//

#import "QupaiSDK.h"
#import "QPEffectMusic.h"
#import "QPUploadTask.h"
#import "QPUploadTaskManager.h"
#import "QPAuth.h"