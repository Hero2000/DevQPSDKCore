//
//  VideoPoint.m
//  QupaiSDK
//
//  Created by yly on 15/6/16.
//  Copyright (c) 2015年 lyle. All rights reserved.
//

#import "QPVideoPoint.h"

@implementation QPVideoPoint

@end
