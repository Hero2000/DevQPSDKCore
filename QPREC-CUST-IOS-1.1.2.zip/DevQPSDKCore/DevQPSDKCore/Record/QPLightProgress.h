//
//  QULightProgress.h
//  qupai
//
//  Created by yly on 14/12/22.
//  Copyright (c) 2014年 duanqu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QPLightProgress : UIView

@property (nonatomic, assign) CGFloat progress;

@end
